<div class="container" style="margin-top:70px;">
  <div class="row">
   
    <div class="col-md-3">
    <?php include("sidemenu.php");?>
      
    </div>
    
    
    <div class="col-md-9">
    
   <?php
            // assignment page here
        if(isset($_GET['post'])){
            
            include("pages/post_assignment_page.php");
            
            // all assignment page here
        }elseif(isset($_GET['al_wrk'])){
            
            include("pages/all_assignment_page.php");
          
            //notification page here
        }elseif(isset($_GET['noti'])){
            
            include("pages/noti_page.php");
          
            //new bids page here
        }elseif(isset($_GET['bid'])){
            
            include("pages/bid_page.php");
            
            //profile page here
        }elseif(isset($_GET['pro'])){
           
            include("pages/profile_page.php");
            
            //send message to the admin page here
        }elseif(isset($_GET['ad_msg'])){
            
            include("pages/msg_admin_page.php");
            
            //logout page here
        }elseif(isset($_GET['logout'])){
          
            include("pages/logout.php");
          
            //solution page here
        }elseif(isset($_GET['solution'])){
          
            include("pages/solution_page.php");
          
            //home page here
        }else{
            include("pages/home_page.php");
        }
        ?> 
  
 






</div>
  </div>
</div>