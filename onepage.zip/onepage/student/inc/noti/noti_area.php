<div>
  <?php
  // open notification
  $noti_list = show_open_noti($_SESSION['std']);
  while ($row = mysqli_fetch_array($noti_list)){
    $msg = $row['2'];
    ?>
    
    <div class="alert alert-dismissible alert-success">
      <?php echo $msg;?>
    </div>
    
    
    <?php
  }
  
  read_noti($_SESSION['std']);
  ?>
</div>


<hr>

<a href="index.php?noti&old">Old Notifications</a>

<?php
if(isset($_GET['old'])){
  // close notification
  $noti_list = show_close_noti($_SESSION['std']);
  while ($row = mysqli_fetch_array($noti_list)){
    $msg = $row['2'];
    ?>
    
    <div class="well">
      <?php echo $msg;?>
    </div>
    
    
    <?php
  }
  
}
?>