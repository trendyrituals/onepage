<div class="table-responsive">
         
          <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th>BID ID</th>
                        <th>ASSIGNMENT ID</th>
                        <th>FILE</th>
                        <th>SATISFY</th>
                    </tr> 
                  </thead>
                  <tbody>
                      <?php
                    $list = solution_list($_SESSION['std']);
                    while ($row = mysqli_fetch_array($list)){
                      $ass_id = $row['0'];
                      $bid_id = $row['2'];
                      $file = $row['3'];
                      ?>
                      
                      <tr>
                         <td><?php echo $bid_id;?></td>
                         <td><?php echo $ass_id;?></td>
                         <td><a href=""><?php echo $file;?></a></td>
                         <td><a style="color:green;" href="">Yes</a> | <a style="color:red;" href="">No</a></td>
                       </tr>
                       
                      <?php
                    }
                    ?>
                       
                  </tbody>
                </table>
      </div>