 <!-- Recent Assignment -->
     <div class="col-md-12" style="margin-top:50px;">
      <div class="panel panel-primary">
       <div class="panel-heading"><i class="fa fa-clock-o" aria-hidden="true"></i> Recent Assignments</div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>ID</th>
                <th>TITLE</th>
                <th>DUE DATE</th>
                <th>STATUS</th>
                <th>VIEW</th>
              </tr>
                
              <tr>
                <td>1</td>
                <td>English</td>
                <td>August 27,2016</td>
                <td>Active</td>
                <td><a href="#" class="btn btn-primary btn-xs">View</a></td>
              </tr>
              
              <tr>
                <td>2</td>
                <td>Maths</td>
                <td>March 3,2017</td>
                <td>Active</td>
                <td><a href="#" class="btn btn-primary btn-xs">View</a></td>
              </tr>
              
            </table>
          </div>
        </div>
      </div>
    </div>
     <!-- Recent Assignment -->