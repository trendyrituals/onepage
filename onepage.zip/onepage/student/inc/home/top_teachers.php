<!-- Teacher list -->
     <div class="col-md-4" style="margin-top:50px;">
       <div class="panel panel-primary">
        <div class="panel-heading"><i class="fa fa-list-alt" aria-hidden="true"></i> Contact-List</div>
        <div class="panel-body">
          <div class="col-md-12" style="margin-top:5px;">
            <span>username</span><span class="navbar-right"><a style="margin-right:5px;" class="btn btn-primary btn-xs" href="">Send Text</a></span>
          </div>
          <div class="col-md-12" style="margin-top:5px;">
            <span>username</span><span class="navbar-right"><a style="margin-right:5px;" class="btn btn-primary btn-xs" href="">Send Text</a></span>
          </div>
          <div class="col-md-12" style="margin-top:5px;">
            <span>username</span><span class="navbar-right"><a style="margin-right:5px;" class="btn btn-primary btn-xs" href="">Send Text</a></span>
          </div>
          
        </div>
      </div>
     </div>
      
     <!-- Teacher list -->