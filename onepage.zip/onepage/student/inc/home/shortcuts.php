<!-- actions -->
    <div class="col-md-12" style="margin-top:50px;">
      <div class="panel panel-primary">
       <div class="panel-heading">Shortcut Links</div>
        <div class="panel-body">
          <div class="row">
            <div class="col-md-4"><a href="index.php?post" class="btn btn-success">New Assignment</a></div>
            <div class="col-md-4"><a href="index.php?ad_msg" class="btn btn-info">Contact Admin</a></div>
            <div class="col-md-4"><a href="index.php?pro" class="btn btn-danger">Profile</a></div>
          </div>
        </div>
      </div>
    </div>
    <!-- actions -->