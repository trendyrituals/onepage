<?php

// post assignment function
function submit_assignment($username,$title,$summary,$subject,$grade,$due_date,$will_pay,$upgrade,$post_attachment){
  global $con;
  $date= date("Y-m-d");
  
  $query ="INSERT INTO assignment (`username`, `title`, `summary`, `subject`, `grade`, `due_date`, `willing_pay`, `file`, `upgrade`, `date`) VALUES ('$username','$title','$summary','$subject','$grade','$due_date','$will_pay','$post_attachment','$upgrade','$date')";
  $result = mysqli_query($con,$query);
  return "<p style='color:green;'>Assignment Submitted</p>";
  
}

//active assignment list function
function active_assignments($username){
  global $con;
  $query = "SELECT * FROM assignment WHERE username = '$username' AND status != '2' ORDER BY id DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

//close assignment list function
function close_assignment($username){
  global $con;
  $query = "SELECT * FROM assignment WHERE username = '$username' AND status = '2' ORDER BY id DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

//user profie data function
function user_data($username){
  global $con;
  $query = "SELECT * FROM student WHERE username = '$username'";
  $result = mysqli_query($con,$query);
  return $result;
}

// update user profile
function update_pro($id,$fullname,$dob,$gender,$address,$email,$phone,$about){
  global $con;
  $query = "UPDATE `student` SET `fullname`='$fullname',`email`='$email',`phone`='$phone',`gender`='$gender',`dob_date`='$dob',`address`='$address',`about`='$about' WHERE `id`='$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?pro");
}

// compose message function here
function compose_msg($to,$message,$from){
  global $con;
  $date = date("Y-m-d");
  $query = "INSERT INTO `message`(`to`, `from`, `message`, `date`) VALUES ('$to','$from','$message','$date')";
  $result = mysqli_query($con,$query);
  return "Message Send";
}

//new message list
function new_msg($to){
  global $con;
  $query = "SELECT * FROM message WHERE `to` = '$to' AND `status` = '0' ORDER BY id DESC ";
  $result = mysqli_query($con,$query);
  return $result;
}

// show message function here
function show_msg($id){
  global $con;
  $query = "SELECT * FROM message WHERE id = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// message reading counter
function msg_read($id){
  global $con;
  $a = 1;
  $query = "UPDATE `message` SET `status`='$a' WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
}

//inbox messages function
function inbox_msg($username){
  global $con;
  $query = "SELECT * FROM message WHERE `to` = '$username' AND `status` = '1' ORDER BY id DESC ";
  $result = mysqli_query($con,$query);
  return $result;
}

//outbox message function here
function outbox_msg($username){
  global $con;
  $query = "SELECT * FROM message WHERE `from` = '$username' ORDER BY id DESC ";
  $result = mysqli_query($con,$query);
  return $result;
}

// bid list for the user here
function bid_list($user){
  global $con;
  $query = "SELECT assignment.id, assignment.username, bid_table.id, bid_table.bidder_user, bid_table.bid_amount, bid_table.clear_pay FROM assignment, bid_table WHERE assignment.id = assignment_id AND username='$user' AND bid_table.assign = '0' AND bid_table.clear_pay ='0' ORDER BY bid_table.id DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

//view bid details function
function view_bid($id){
  global $con;
  $query = "SELECT * FROM bid_table WHERE id = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

//payment form details for a specific bid
function bid_pay($bid_id){
  global $con;
  $query = "SELECT * FROM bid_table WHERE id = '$bid_id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// save payment information into the payment table
function save_payment_data($bid_id,$user,$amount,$currency,$trx_id){
  global $con;
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  $query = "INSERT INTO `payment_table`(`bid_id`, `username`, `amount`, `currency`, `transection_id`, `date`) VALUES ('$bid_id','$user','$amount','$currency','$trx_id','$date')";
  $result = mysqli_query($con,$query);
  
}

// get assignment for view assignment details
function get_assignment($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// this is the admin msg function 
function send_msg_admin($username,$msg,$subject){
    global $con;
    date_default_timezone_set('Asia/Kolkata');
    $date = date("Y-m-d");
    $query = "INSERT INTO `message`( `username`, `subject`, `message`, `date`) VALUES ('$username','$subject','$msg','$date')";
    $result = mysqli_query($con,$query);
    return "Message Successfully Send";
}

// upgrade add to bid pay amount 
function see_upgrade($ass_id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$ass_id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// subject list 
function show_subject(){
  global $con;
  $query = "SELECT * FROM subject";
  $result = mysqli_query($con,$query);
  return $result;
}

// fuction for notification span
function noti_row($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '0'";
  $result = mysqli_query($con,$query);
  $num = mysqli_num_rows($result);
  return $num;
}

// function for show open notification
function show_open_noti($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '0' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// function for show close notification
function show_close_noti($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// read noti update
function read_noti($user){
  global $con;
  $query = "UPDATE `notification` SET `read`='1' WHERE `username` = '$user' AND `read` = '0'";
  $result  = mysqli_query($con,$query);
}

// reject bid 
function reject_bid($id){
  global $con;
  $query = "DELETE FROM `bid_table` WHERE `id` = '$id'";
  $reuslt = mysqli_query($con,$query);
  header("location:index.php?bid");
}

// post comment
function comment_post($id,$msg,$post_attachment){
  global $con;
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  $query = "INSERT INTO `comment`(`ass_id`, `msg`, `file`, `date`) VALUES ('$id','$msg','$post_attachment','$date')";
  $result = mysqli_query($con,$query);  
}

// show comment
function show_comment($id){
  global $con;
  $query = "SELECT * FROM `comment` WHERE `status` = '1' AND `ass_id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// solution list
function solution_list($user){
  global $con;
  $query = "SELECT assignment.id, assignment.username, bid_table.id,bid_table.solution FROM assignment, bid_table WHERE assignment.id = assignment_id AND username='$user' AND bid_table.status = '2'";
  $result = mysqli_query($con,$query);
  return $result;
}





?>