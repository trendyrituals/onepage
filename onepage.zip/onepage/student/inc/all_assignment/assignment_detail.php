<!--detail assignment here -->
   <?php

if(isset($_GET['view'])){
  $id = $_GET['view'];
  $details = get_assignment($id);
  while ($row = mysqli_fetch_array($details)){
    $id = $row['0'];
    $title = $row['2'];
    $summary = $row['3'];
    $grade = $row['5'];
    $will_pay = $row['7'];
    $due = $row['6'];
    $attach = $row['8'];
    $post = $row['10'];
    $sub = $row['4'];
    ?>
    <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><i class="fa fa-tasks" aria-hidden="true"></i> Assignment Detail</h3>
  </div>
  <div class="panel-body">
    <div>
      
      <div><b>Project ID:</b> <?php echo $id;?></div>
      <div><b>Title:</b> <?php echo $title;?></div>
      <div><b>Subject:</b> <?php echo $sub;?></div>
      <div>
      <b>Project Summary:</b>
      <?php echo $summary;?>
      </div>
      <div>
      <b>Attachment:</b>
       <a href="index.php?al_wrk&view=<?php echo $id;?>&attach_file=<?php echo $attach;?>"><?php echo $attach;?></a>
       </div>
      <div><b>Willing To Pay:</b> $<?php echo $will_pay;?></div>
      <div><b>Grade Wants:</b> <?php echo $grade;?></div>
      <div><b>Due Date:</b> <?php echo $due;?></div>
      <div><b>Post Date:</b><?php echo $post;?></div>
      
      <div class="navbar-right" style="margin-right:5px;">
      <span><a href="index.php?al_wrk" class="btn btn-danger btn-xs">Close</a></span>
      </div>
      
      <?php
      $list = show_comment($id);
      while($rows = mysqli_fetch_array($list) ){
        $msg = $rows['2'];
        $file = $rows['3'];
        ?>
        <div class="well" style="margin-top:40px;margin-bottom:20px;">
        <span><b>Comment:</b></span>
        <?php echo $msg;?>
        <br>
        <br>
        <div><span><b>File:</b></span><a href="index.php?al_wrk&view=<?php echo $id;?>&attach_file=<?php echo $file;?>"><?php echo $file;?></a></div>
        </div>
        
        
        <?php
      }
      ?>
      
      
      
      <div class="navbar-right" style="margin-right:5px;">
      <span><a href="index.php?al_wrk&view=<?php echo $id;?>&post_com=<?php echo $id;?>" class="btn btn-success btn-xs">Comment</a></span>
      </div>
      
    </div>
  </div>
</div>
  
   <?php
if(isset($_GET['post_com'])){
  $id = $_GET['post_com'];
  ?>
  <div style="margin-bottom:50px;">
    <form action="index.php?al_wrk&view=<?php echo $id;?>&post_com=<?php echo $id;?>" method="post" enctype="multipart/form-data">
     <input type="hidden" name="id" value="<?php echo $id;?>">
      <textarea class="form-control" name="com_msg" rows="3"></textarea>
      <input type="file" name="com_attach">
      <button class="btn btn-primary" name="comment" style="margin-top:10px;" type="submit">Send</button>
    </form>
  </div>
  
  
  <?php
}

?>
   
   
   <?php
// download resume file here
if(isset($_GET['attach_file']) && basename($_GET['attach_file'] == $_GET['attach_file'])){
  $filename = $_GET['attach_file'];
  $path = '../files/'.$filename;
  
  if(file_exists($path) && is_readable($path)){
    $size = filesize($path);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename='.$filename);
    header('Content-Transfer-Encoding: binary');
    ob_clean();
    flush();
    $file = @fopen($path,'rb');
    if($file){
      fpassthru($file);
      exit;
    }
  }
}


  }
}
?>
   
<?php
if(isset($_POST['comment'])){
  $id = $_POST['id'];
  $msg = $_POST['com_msg'];
  $post_attachment = $_FILES ['com_attach']['name']; // this is the image name the real image
  $attachment_tmp = $_FILES ['com_attach']['tmp_name']; // this is the tmp name for the image
  
  move_uploaded_file($attachment_tmp,"../files/$post_attachment"); // here we are moving image to the website folder
  
  comment_post($id,$msg,$post_attachment);
}

?>
    
    <!--detail assignment here -->