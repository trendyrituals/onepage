<!--active assignment here -->
      <div class="panel panel-primary">
      <div class="panel-heading">
      <h3 class="panel-title"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Active Assignments</h3>
      </div>
      <div class="panel-body">
      <div class="table-responsive">
         
          <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th class="hidden-xs">ID</th>
                        <th>TITLE</th>
                        <th>SUMMARY</th>
                        <th>DUE DATE</th>
                        <th>STATUS</th>
                    </tr> 
                  </thead>
                  <tbody>
                         
                         <?php
                    $username = $_SESSION['std'];
                    $list = active_assignments($username);
                    while($row = mysqli_fetch_array($list)){
                      $id = $row['0'];
                      $title = $row['2'];
                      $summary = substr($row['3'],0,40);
                      $due_date = $row['6'];
                      ?>
                        <tr>
                          <td align="center">
                            <a href="index.php?al_wrk&view=<?php echo $id;?>" class="btn btn-info btn-xs">View</a>
                            <a href="#" class="btn btn-warning btn-xs">Delete</a>
                          </td>
                          <td class="hidden-xs"><?php echo $id;?></td>
                          <td><?php echo $title;?></td>
                          <td><?php echo $summary;?></td>
                          <td><?php echo $due_date;?></td>
                          <td>Active</td>
                        </tr>
                      
                      <?php
                    }
                    ?>
                         
                         
                          
                        </tbody>
                </table>
      </div>
      </div>
      </div><!-- active assignment  here -->
      