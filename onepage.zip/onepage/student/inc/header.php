<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DashBoard | Student</title>
  <link href="css/superhero.css" rel="stylesheet">
  <link href="css/animated.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Exo" rel="stylesheet">
  
<script src="https://use.fontawesome.com/5ed0e44143.js"></script>

</head>
<body>