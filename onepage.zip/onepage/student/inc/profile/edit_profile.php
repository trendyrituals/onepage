<!--edit profile data here -->
    <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Profile</h3>
  </div>
  <div class="panel-body">
    <form class="form-horizontal" action="index.php?pro&edit_pro" method="post">
<fieldset>
<?php
if(isset ($_GET['edit_pro'])){
  $id = $_GET['edit_pro'];
}
?> 

<!-- Text input--> 
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Full Name</label>  
  <div class="col-md-4">
  <input id="textinput" name="fullname" placeholder="David John" class="form-control input-md" type="text">
  <input id="textinput" name="id" value="<?php echo $id;?>" class="form-control input-md" type="hidden">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Date Of Birth</label>  
  <div class="col-md-4">
  <input id="textinput" name="dob" placeholder="DD/MM/YYYY" class="form-control input-md" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Gender</label>  
  <div class="col-md-4">
  <input id="textinput" name="gender" placeholder="Male" class="form-control input-md" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Home Address</label>  
  <div class="col-md-4">
  <input id="textinput" name="address" placeholder="Add" class="form-control input-md" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Email</label>  
  <div class="col-md-4">
  <input id="textinput" name="email" placeholder="eh: zeph@zmail.com" class="form-control input-md" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Phone Number</label>  
  <div class="col-md-4">
  <input id="textinput" name="phone" placeholder="1234567890" class="form-control input-md" type="text">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">About Yourself</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" name="about"></textarea>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button id="singlebutton" name="update_pro" class="btn btn-primary">Update</button>
  </div>
</div>

</fieldset>
</form>
  </div>
</div>
    <!--edit profile data here -->
    
   
  
 
<?php
if(isset($_POST['update_pro'])){
  if(!empty($_POST['id']) &&!empty($_POST['fullname']) && !empty($_POST['dob']) && !empty($_POST['gender']) && !empty($_POST['address']) && !empty($_POST['email']) && !empty($_POST['phone']) && !empty($_POST['about'])){
    $id = $_POST['id'];
    $fullname = mysqli_real_escape_string($con,$_POST['fullname']);
    $dob = mysqli_real_escape_string($con,$_POST['dob']);
    $gender = mysqli_real_escape_string($con,$_POST['gender']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $phone = mysqli_real_escape_string($con,$_POST['phone']);
    $about = mysqli_real_escape_string($con,$_POST['about']);
    
    update_pro($id,$fullname,$dob,$gender,$address,$email,$phone,$about);
  }
  
}
?>