<!--profile data here -->
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="fa fa-user" aria-hidden="true"></i> User Profile</h3>
        </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-md-3">
              <img src="img/blank.png" style="width:100%;" alt="">
              <a href="#" class="btn btn-info btn-xs">Change Picture</a>
            </div>
            
            <div class="col-md-9 table-responsive">
               <table class="table table-user-information">
                    <tbody>
                     
                     <?php
                      $username = $_SESSION['std'];
                      $details = user_data($username);
                      while($row = mysqli_fetch_array($details)){
                        $id = $row['0'];
                        $username = $row['1'];
                        $fullname = $row['2'];
                        $email = $row['3'];
                        $phone = $row['4'];
                        $gender = $row['6'];
                        $dob = $row['7'];
                        $address = $row['8'];
                        $about = $row['9'];
                        $date = $row['11'];
                      }
                      ?>
                     
                      <tr>
                        <td>User Name:</td>
                        <td><?php echo $username;?></td>
                      </tr>
                      <tr>
                        <td>Full Name:</td>
                        <td><?php echo $fullname;?></td>
                      </tr>
                      <tr>
                        <td>Date of Birth:</td>
                        <td><?php echo $dob;?></td>
                      </tr>
                  
                       <tr>
                        <td>Gender:</td>
                        <td><?php echo $gender;?></td>
                      </tr>
                        <tr>
                        <td>Home Address:</td>
                        <td><?php echo $address;?></td>
                      </tr>
                      <tr>
                        <td>Email:</td>
                        <td><?php echo $email;?></td>
                      </tr>
                       <tr>
                        <td>Phone Number:</td>
                        <td><?php echo $phone;?></td>                           
                      </tr>
                                         
                    </tbody>
                  </table>
                  <p><?php echo $about;?></p>
                  
                  <a href="index.php?pro&edit_pro=<?php echo $id;?>" class="btn btn-info btn-xs">Edit</a>
            </div>
          </div>
        </div>
      </div>
    <!--profile data here -->