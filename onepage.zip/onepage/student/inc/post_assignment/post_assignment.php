
<!--new assignment form -->
     <div class="col-md-8">
        <div class="panel panel-primary">
        <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-file" aria-hidden="true"></i> Post Assignment</h3>
        </div>
        <div class="panel-body">
        



<?php
if(isset($_POST['post_work'])){
  if(!empty($_POST['title']) && !empty($_POST['summary']) && ($_POST['subject'] !='Select One') && !empty($_POST['due_date']) && !empty($_POST['will_pay'])){
    
    $username = $_SESSION['std'];
    $title = mysqli_real_escape_string($con,$_POST['title']);
    $summary = $_POST['summary'];
    $subject = mysqli_real_escape_string($con,$_POST['subject']);
    $grade = mysqli_real_escape_string($con,$_POST['grade']);
    $due_date = mysqli_real_escape_string($con,$_POST['due_date']);
    $will_pay = mysqli_real_escape_string($con,$_POST['will_pay']);
    //echo $attachment = mysqli_real_escape_string($con,$_POST['attachment']);
  if($_POST['upgrade']== "yes"){
    $upgrade = 1;
  }elseif($_POST['upgrade']== "no"){
    $upgrade = 0;
  }
  
    $post_attachment = $_FILES ['attachment']['name']; // this is the image name the real image
    $attachment_tmp = $_FILES ['attachment']['tmp_name']; // this is the tmp name for the image
  
  move_uploaded_file($attachment_tmp,"../files/$post_attachment"); // here we are moving image to the website folder
    echo submit_assignment($username,$title,$summary,$subject,$grade,$due_date,$will_pay,$upgrade,$post_attachment);
  }else{
    echo"<p style='color:red;'>Some Fields Missing</p>";
  }
  
}
?> 
    
        
        
        
        
        <form action="index.php?post" method="post" enctype="multipart/form-data">
         <div class="form-group">
    <label for="exampleInputName2">Title</label>
    <input type="text" class="form-control" id="exampleInputName2" name="title" placeholder="Title Here">
  </div>
     
      <div class="form-group">
    <label for="exampleInputName2">Summary</label>
     <textarea class="form-control ckeditor" rows="3" name="summary"></textarea>
                <script src="//cdn.ckeditor.com/4.5.10/standard/ckeditor.js"></script>
  </div>
     
     <div class="form-group">
    <label for="exampleInputName2">Subject</label>
    <select class="form-control" name="subject">
  <option>Select One</option>
  <?php
      $list = show_subject();
      while ($row = mysqli_fetch_array($list)){
        $sub = $row['1'];
        ?>
        <option><?php echo $sub;?></option>
        <?php
      }
      ?>
</select>
  </div>
    
    <div class="form-group">
    <label for="exampleInputName2">Grade Level(%)</label>
    <input type="text" class="form-control" name="grade" id="exampleInputName2" placeholder="eg: 90,eg:80">
  </div>
     
     <div class="form-group">
    <label for="exampleInputName2">Due Date</label>
    <input type="text" class="form-control" name="due_date" id="exampleInputName2" placeholder="YYYY-MM-DD">
  </div>
     
     <div class="form-group">
    <label for="exampleInputName2">Willing To Pay($)</label>
    <input type="text" class="form-control" name="will_pay" id="exampleInputName2" placeholder="0">
  </div>
    
    <div class="form-group">
    <label for="exampleInputName2">Attachment</label>
    <input type="file" name="attachment">
  </div>
    
    <div class="radio form-group">
         <span class="label label-warning">CheckBoxes:</span><br><br>
          <label>
            <input name="upgrade" id="optionsRadios2" value="yes" type="radio">
            You may click - For Urgent Project <i class="fa fa-clock-o" aria-hidden="true"></i> - $24.99 Extra.
          </label>
        </div>
        
        <div class="radio form-group">
          <label>
            <input name="upgrade" id="optionsRadios2" value="no" type="radio">
            Priority Normal. 
          </label>
        </div>
     
     <div class="form-group">
    <button class="btn btn-success" type="submit" name="post_work">Submit</button>
  </div>
     
     
     
      </form>
        </div>
      </div>
     </div>
    <!--new assignment form -->