<div class="col-md-4">
      <!--new assignment related text info -->

<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Info Related The Form</h3>
  </div>
  <div class="panel-body">
   <ul>
         <li style="margin-bottom:10px;">when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</li>
         <li style="margin-bottom:10px;">when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</li>
         <li style="margin-bottom:10px;">when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</li>
       </ul>
  </div>
</div><!--new assignment related text info -->
       
     </div>