<?php
if(isset($_GET['success_pay'])){
  $bid_id = $_SESSION['bid_id'];
  $user = $_SESSION['std'];
  
  $amount = $_GET['amt'];
  $currency = $_GET['cc'];
  $trx_id = $_GET['tx'];
  save_payment_data($bid_id,$user,$amount,$currency,$trx_id);
  unset($_SESSION['bid_id']);
  echo "<h3 style='color:green;'>Payment Successfull</h3></br><p>Reject All Remainning Bids</p>";
}
?>