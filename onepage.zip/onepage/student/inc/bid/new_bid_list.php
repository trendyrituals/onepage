<div class="table-responsive">
  
        <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th class="hidden-xs">ID</th>
                        <th>PROJECT ID</th>
                        <th>BID BY</th>
                        <th>AMOUNT</th>
                        <th>VIEW</th>
                    </tr> 
                  </thead>
                  <tbody>
                         
                         <?php
                    $user  = $_SESSION['std'];
                    $list = bid_list($user);
                    while ($row = mysqli_fetch_array($list)){
                      $ass_id = $row['0'];
                      $bid_id = $row['2'];
                      $bidder = $row['3'];
                      $amt = $row['4'];
                      ?>
                       <tr>
                            <td><?php echo $bid_id;?></td>
                            <td><?php echo $ass_id;?></td>
                            <td><?php echo $bidder;?></td>
                            <td>$<b><?php echo $amt;?></b></td>
                            <td>
                            <a href="index.php?bid&view_bid=<?php echo $bid_id;?>" class="btn btn-info btn-xs">View</a>
                            <a href="index.php?bid&reject_bid=<?php echo $bid_id;?>" class="btn btn-danger btn-xs">Reject</a></td>
                          </tr>
                      
                      
                      <?php
                    }
                    ?>
                         
                  
                        </tbody>
                </table>
           
</div>
<?php
                     
if(isset($_GET['reject_bid'])){
  $id = $_GET['reject_bid'];
  reject_bid($id);
}
?>