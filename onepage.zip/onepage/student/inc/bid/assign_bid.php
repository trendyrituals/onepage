<?php
if(isset($_GET['assign_bid'])){
  $bid_id = $_GET['assign_bid'];
  
  $_SESSION['bid_id'] = $bid_id;
  
  $list = bid_pay($bid_id);
  while ($row = mysqli_fetch_array($list)){
    $bid_no = $row['0'];
    $ass_id = $row['1'];
    $bid_amt = $row['5'];
    
    $up = see_upgrade($ass_id);
    while($upz = mysqli_fetch_array($up)){
      $upgrade = $upz['9'];
      if($upgrade == 1){
        $extra = "24.99";
        $process_fee = ($bid_amt*10)/100;
        $total_amt = $bid_amt +$process_fee + $extra;
      }else{
        $process_fee = ($bid_amt*10)/100;
        $total_amt = $bid_amt + $process_fee;
      }
      ?>
      
      <div>
        <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><i class="fa fa-money" aria-hidden="true"></i> Make Payment And Assign Bid</h3>
  </div>
  <div class="panel-body">
    
   
   
   
   
   
   <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

  <!-- Identify your business so that you can collect the payments. -->
  <input type="hidden" name="business" value="boss_bhawani_account@gmail.com">

  <!-- Specify a Buy Now button. -->
  <input type="hidden" name="cmd" value="_xclick">

  <!-- Specify details about the item that buyers will purchase. -->
  <input type="hidden" name="item_name" value="<?php echo $bid_no;?>">
  <input type="hidden" name="amount" value="<?php echo $total_amt;?>">
  <input type="hidden" name="currency_code" value="USD">

  <!-- Display the payment button. -->
  <input type="image" name="submit" border="0"
  src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
  alt="PayPal - The safer, easier way to pay online">
  <img alt="" border="0" width="1" height="1"
  src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

</form>


    
    </div>
  </div>
</div>
      
      
      <?php
    }
  }

}
?>
       

       
      