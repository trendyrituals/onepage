<?php
if(isset($_GET['view_bid'])){
  $id = $_GET['view_bid'];
  $rslt = view_bid($id);
  while($row= mysqli_fetch_array($rslt)){
    $id = $row['0'];
    $ass_id = $row['1'];
    $bidder = $row['2'];
    $grade = $row['4'];
    $msg = $row['3'];
    $bid_amt = $row['5'];
    $date = $row['6'];
    
    ?>
    
    <div>
        <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><i class="fa fa-briefcase" aria-hidden="true"></i> Bidder Detail And Purposal</h3>
  </div>
  <div class="panel-body">
    <div>
      <div><b>Bid ID:</b> <?php echo $id;?></div>
      <div><b>Project ID:</b> <?php echo $ass_id;?></div>
      <div><b>Bidder Name:</b> <?php echo $bidder;?></div>
      <div><b>Purposal Message:</b><?php echo $msg;?></div>
      <div><b>Grade:</b><?php echo $grade;?></div>
      <div><b>Amount:</b> <?php echo $bid_amt;?></div>
      <div><b>Date:</b> <?php echo $date;?></div>
      <div class="navbar-right" style="margin-right:5px;">
      <span><a href="index.php?bid&assign_bid=<?php echo $id;?>" class="btn btn-success btn-xs">Assign Bid</a></span>
      <span><a href="index.php?bid&reject_bid" class="btn btn-danger btn-xs">Reject</a></span>
      </div>
    </div>
  </div>
</div>
      </div>
    
    
    <?php
  }
}
?>      
      