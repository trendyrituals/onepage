<?php
include ("inc/solution/solution_table.php");
?>