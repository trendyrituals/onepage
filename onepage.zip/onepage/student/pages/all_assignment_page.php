<?php

if(isset($_GET['view'])){
  include("inc/all_assignment/assignment_detail.php");
  include("inc/all_assignment/active_assignment.php");
  include("inc/all_assignment/close_assingment.php");
  
}else{
  include("inc/all_assignment/active_assignment.php");
  include("inc/all_assignment/close_assingment.php");

}

?>