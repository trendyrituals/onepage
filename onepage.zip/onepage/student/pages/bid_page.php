<?php
include("inc/bid/bid_note.php");
include("inc/bid/success_pay.php");
include("inc/bid/view_bid.php");
include("inc/bid/assign_bid.php");
include("inc/bid/new_bid_list.php");


?>
