<?php
include ("inc/noti/noti_area.php");
?>