<?php

include("inc/profile/profile_data.php");
if(isset ($_GET['edit_pro'])){
  include("inc/profile/edit_profile.php");
}


?>