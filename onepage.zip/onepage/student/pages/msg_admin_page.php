<?php

include("inc/message_admin/admin_msg_note.php");
include("inc/message_admin/admin_msg_form.php");

?>