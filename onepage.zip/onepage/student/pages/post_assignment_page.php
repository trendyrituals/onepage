<?php

include ("inc/post_assignment/post_assignment.php");
include ("inc/post_assignment/assignment_text.php");
?>