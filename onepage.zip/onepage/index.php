<?php require_once ("inc/db.php");?>
<?php require_once ("inc/function.php");?>
<?php
include ("inc/header.php");
include ("inc/navbar.php");
?>

<?php
// this is the about page
if(isset($_GET['about'])){
 
    include ("inc/about_img.php");
    include ("inc/aboutus.php");

}
// this is the contact us page
elseif(isset($_GET['contactus'])){

    include ("inc/contact_img.php");
    include ("inc/contact_form.php");
  
}
// this is the signup page
elseif(isset($_GET['signup'])){
    
    include ("inc/signup_img.php");
    include ("inc/sign_up_content.php");
  
}
// this is the services page
elseif(isset($_GET['services'])){
  
    include ("inc/services_img.php");
    include ("inc/services_box.php");
  
}
// this is the home page
else{
  
include ("inc/imgheader.php");
include ("inc/join_btn.php");
include ("inc/subscribe.php");
include ("inc/information_box.php");

}
?>

<?php
      include ("inc/footer.php");      
?>