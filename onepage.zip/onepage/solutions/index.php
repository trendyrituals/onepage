<html>
	<head>
		<title>AgentOrange</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
	</head>

<body>
    <!-- Header start -->
    <div>
        <?php include 'includes/header.php';?>    
    </div>
    
    <!-- Banner start -->
    <div>
        <?php include 'includes/banner.php';?>    
    </div>
    
    <!-- Points And form -->
    <div>
        <?php include 'includes/points.php';?>    
    </div>
    
    <!-- Post and follow  -->
    <div class="row zero_margin">
        
        <div class="col-md-8">
            <?php include 'includes/recentupload.php';?>
        </div>
        
        <div class="col-md-4">
            <?php include 'includes/follow.php';?>
        </div>
        
    </div>
    



<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>