<?php
include ("inc/home/welcomenote.php");
include ("inc/home/shortcut.php");
?>