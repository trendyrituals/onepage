<?php
include ("inc/account/paypal_set.php");
include ("inc/account/account_balance.php");
include ("inc/account/update_email.php");
include ("inc/account/paypal_email.php");
include ("inc/account/payment_history.php");
?>