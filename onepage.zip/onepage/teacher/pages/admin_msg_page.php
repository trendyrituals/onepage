<?php
include ("inc/admin_msg/msg_to_admin.php");
?>