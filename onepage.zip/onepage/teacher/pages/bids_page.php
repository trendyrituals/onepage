<?php
include ("inc/bids/bids_details.php");
include ("inc/bids/add_bids.php");
?>