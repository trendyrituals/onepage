<?php
include ("inc/profile/user_details.php");
include ("inc/profile/edit_profile.php");
?>