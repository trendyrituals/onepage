<?php
include ("inc/browse_assignment/browse.php");
include ("inc/browse_assignment/view_assignment.php");
include ("inc/browse_assignment/bidding_page.php");
include ("inc/browse_assignment/assignment_table.php");
?>