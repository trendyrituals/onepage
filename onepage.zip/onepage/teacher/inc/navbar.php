<!--navbar -->
 <nav class="navbar navbar-static-top navbar-fixed-top navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">DashBoard</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  
      <ul class="nav navbar-nav navbar-right">
       
        <li><a href="index.php?br_as"><i class="fa fa-tasks" aria-hidden="true"></i> Browse Assignments</a></li>
        
        
        <li><a href="index.php?noti"><i class="fa fa-bell" aria-hidden="true"></i> Notification <span class="label label-warning"><?php echo noti_row($_SESSION['teach']);?></span></a></li>
        
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> <?php echo $_SESSION['teach'];?> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="index.php?pro"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
            <li><a href="#"><i class="fa fa-cogs" aria-hidden="true"></i> Setting</a></li>
    
            <li role="separator" class="divider"></li>
            <li><a href="index.php?logout"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
            
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav><!--navbar -->