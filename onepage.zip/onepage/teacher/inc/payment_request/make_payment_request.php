<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Make Payment Request</h3>
  </div>
  <div class="panel-body">
   
   <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input class="form-control" placeholder="Assignment ID" type="text">
        </div>
        <div class="form-group">
          <input type="file">
        </div>
        <button type="submit" class="btn btn-default">Make Request</button>
        <p style="margin-top:10px;"><span class="label label-warning">Note</span>Attach Solution For The Assignment</p>
      </form>
   
  </div>
</div>