<?php
if(isset ($_GET['solution'])){
  $id_bid = $_GET['solution'];
  ?>
  
  <form action="index.php?a_task&solution" enctype="multipart/form-data" method="post">
    <input type="hidden" name="id" value="<?php echo $id_bid;?>">
    <input type="file" name="solution">
    <button type="submit" name="sol_file" class="btn btn-success">Upload</button>
  </form>
  
  <?php
}

if(isset($_POST['sol_file'])){
  echo $bid_id = $_POST['id'];
  $post_file = $_FILES ['solution']['name']; // this is the image name the real image
  $file_tmp = $_FILES ['solution']['tmp_name']; // this is the tmp name for the image
  
  move_uploaded_file($file_tmp,"../solutions/$post_file"); // here we are moving image to the website folder
  
  upload_solution($bid_id,$post_file);
  inform_student($bid_id);
  
}
?>    
          <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Active Tasks</h3>
  </div>
  <div class="panel-body">
     <div class="table-responsive">
         
          <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th class="hidden-xs">ID</th>
                        <th>ASSIGNMENT</th>
                        <th>AMOUNT</th>
                        <th>DUE DATE</th>
                        <th>UPLOAD SOLUTION</th>
                    </tr> 
                  </thead>
                  <tbody>
                         
                         <?php
                    $username = $_SESSION['teach'];
                    $list = active_task($username);
                    while ($row = mysqli_fetch_array($list)){
                      $id = $row['0'];
                      $ass_id = $row['1'];
                      $bid_amt = $row['5'];
                      $date = $row['6'];
                      ?>
                      
                      <tr>
                            <td align="center">
                              <a href="index.php?a_task&view_task=<?php echo $ass_id;?>" class="btn btn-info btn-xs">View</a>
                            </td>
                            <td class="hidden-xs"><?php echo $id;?></td>
                            <td><?php echo ass_name($ass_id);?></td>
                            <td><?php echo $bid_amt;?></td>
                            <td><?php echo ass_due_date($ass_id);?></td>
                            <td>
                            <a class="btn btn-warning btn-xs" href="index.php?a_task&solution=<?php echo $id;?>">Upload Solution</a></td>
                            
                          </tr>
                          
                      
                      <?php
                    }
                    ?>
                          
                          
                        </tbody>
                </table>
      </div>
  </div>
</div>   


