   <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Bids</h3>
  </div>
  <div class="panel-body table-responsive">
    <table class="table table-bordered">
     <tbody>
      <tr>
        <td>Bids Remaining:</td>
        <?php
        $list = count_bid($_SESSION['teach']);
        while($row = mysqli_fetch_array($list)){
          $bid = $row['2'];
          ?>
          <td><?php echo $bid;?></td>
          <?php
        }
        ?>
        
      </tr>
      <tr>
        <td>Disputed Assignment:</td>
        <td>0</td>
      </tr>
      <tr>
        <td>Refunds Issued:</td>
        <td>0</td>
      </tr>
      </tbody>
    </table>
  </div>
</div>