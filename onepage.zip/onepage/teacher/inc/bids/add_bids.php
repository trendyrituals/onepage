<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Add 50 Bids To Your Account</h3>
  </div>
  <div class="panel-body">
    <form action="">
      <button class="btn btn-primary">Paypal</button>
      
      <p style="margin-top:10px;"><span class="label label-warning">Note</span>Add 50 Bids To Your Account In Just $25</p>
    </form>
    
  </div>
</div>