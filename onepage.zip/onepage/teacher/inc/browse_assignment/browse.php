<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Browse Assignment <small>By Subject</small></h3>
  </div>
  <div class="panel-body">
   
   <form class="navbar-form navbar-left" action="index.php?br_as" method="post" role="search">
        <div class="form-group">
          <div class="col-lg-10">
        <select class="form-control" id="select" name="subject">
          <option>--Select One--</option>
          <?php
      $list = show_subject();
      while ($row = mysqli_fetch_array($list)){
        $sub = $row['1'];
        ?>
        <option><?php echo $sub;?></option>
        <?php
      }
      ?>
        </select>
            </div>
        </div>
        <button type="submit" name="sub" class="btn btn-default">Search</button>
      </form>
   
  </div>
</div>