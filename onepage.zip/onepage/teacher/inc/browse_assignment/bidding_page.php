<?php
if(isset ($_GET['place_bid'])){
  $id = $_GET['place_bid'];
  $user = $_SESSION['teach'];
  $count = check_bid($user);
  while($row = mysqli_fetch_array($count)){
    $bid_no = $row['2'];
    if($bid_no > 0){
      ?>
      <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Place Bid</h3>
  </div>
  <div class="panel-body">
     <form class="form-horizontal" action="index.php?br_as" method="post">
<fieldset>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Enter Bid Amount: $</label>  
  <div class="col-md-4">
  <input id="textinput" name="bid_amt" placeholder="200" class="form-control input-md" type="text">
  <input id="textinput" name="ass_id"  type="hidden" value="<?php echo $id;?>">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">Purposal Message:</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" name="purposal"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Grade With:</label>  
  <div class="col-md-4">
  <input id="textinput" name="grade" placeholder="eg: 75" class="form-control input-md" type="text">
    
  </div>
</div>
 
 <div class="form-group">
  
  <div class="col-md-4 navbar-right">                     
    <button class="btn btn-info btn-xs" type="submit" name="place">Submit</button>
  </div>
</div>

</fieldset>
</form>
 <hr>
 <p><span class="label label-warning">Note</span> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p>
  </div>
</div>
  
      <?php
      
    }else{
      echo "<h3>Bid Not Available</h3>";
    }
  }
}
  
if(isset($_POST['place'])){
  $ass_id = $_POST['ass_id'];
  $bid_amt = $_POST['bid_amt'];
  $msg = $_POST['purposal'];
  $grade = $_POST['grade'];
  $bidder = $_SESSION['teach'];
  echo place_bid($ass_id,$bid_amt,$msg,$grade,$bidder);
  $now = cut_bid($_SESSION['teach']);
  while($rows = mysqli_fetch_array($now)){
    $bid_no = $rows['2'];
    $username = $_SESSION['teach'];
    update_bid($bid_no,$username);
  }
 
}


?>



