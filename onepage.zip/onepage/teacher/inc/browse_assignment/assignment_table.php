<?php
if(isset($_SESSION['teach'])){
  $user = $_SESSION['teach'];
  $list = find_permission($user);
  while($row = mysqli_fetch_array($list)){
    $permission = $row['0'];
    if($permission == 1){
      ?>
      
      <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Active Assignment <small>For Subject</small></h3>
  </div>
  <div class="panel-body">
     <div class="table-responsive">
         
          <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th class="hidden-xs">ID</th>
                        <th>TITLE</th>
                        <th>SUBJECT</th>
                        <th>DUE-DATE</th>
                        <th>BID</th>
                    </tr> 
                  </thead>
                  <tbody>
                         <?php
                    if(isset($_POST['sub'])){
                       $subject = $_POST['subject'];
                      $list = subject_assignment($subject);
                      while($row = mysqli_fetch_array($list)){
                        $id = $row['0'];
                        $title = $row['2'];
                        $subject = $row['4'];
                        $due_date = $row['6'];
                        
                        ?>
                        
                        <tr>
                            <td align="center">
                              <a href="index.php?br_as&view_ass=<?php echo $id;?>" class="btn btn-info btn-xs">View</a>
                            </td>
                            <td class="hidden-xs"><?php echo $id;?></td>
                            <td><?php echo $title;?></td>
                            <td><?php echo $subject;?></td>
                            <td><?php echo $due_date;?></td>
                            <td><?php echo count_bid_assignment($id);?></td>
                          </tr>
                        
                        
                        <?php
                      }
                    }else{
                      $list = all_subject();
                      $list = all_subject();
                      while($row = mysqli_fetch_array($list)){
                        $id = $row['0'];
                        $title = $row['2'];
                        $subject = $row['4'];
                        $due_date = $row['6'];
                        ?>
                         <tr>
                            <td align="center">
                              <a href="index.php?br_as&view_ass=<?php echo $id;?>" class="btn btn-info btn-xs">View</a>
                            </td>
                            <td class="hidden-xs"><?php echo $id;?></td>
                            <td><?php echo $title;?></td>
                            <td><?php echo $subject;?></td>
                            <td><?php echo $due_date;?></td>
                            <td><?php echo count_bid_assignment($id);?></td>
                          </tr>
                        
                        <?php
                    }
                    }
                    ?>
                          
                         
                        </tbody>
                </table>
      </div>
  </div>
</div>
      
      
      <?php
    }else{
      ?>
      
      <div>
       <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, 
       </p>
       
       
        <form action="index.php?br_as" method="post" enctype="multipart/form-data">
          <div>Resume: <input type="file" name="resume"></div>
          <div>Degree: <input type="file" name="degree"></div>
          <div><button type="submit" name="resume_submit" class="btn btn-success">Upload</button></div>
          <?php
if(isset($_POST['resume_submit'])){
  $resume = $_FILES['resume'];
  $degree = $_FILES['degree'];
  
  //for resume
  $post_resume = $_FILES ['resume']['name']; // this is the image name the real image
  $resume_tmp = $_FILES ['resume']['tmp_name']; // this is the tmp name for the image

  move_uploaded_file($resume_tmp,"../user_data/resume/$post_resume"); // here we are moving image to the website folder
  
  //for degree
  $post_degree = $_FILES ['degree']['name']; // this is the image name the real image
  $degree_tmp = $_FILES ['degree']['tmp_name']; // this is the tmp name for the image

  move_uploaded_file($degree_tmp,"../user_data/degree/$post_degree"); // here we are moving image to the website folder
  
  if(!empty($resume_tmp) && !empty($degree_tmp)){
    $username = $_SESSION['teach'];
    echo upload_user_resume($username,$post_resume,$post_degree);
    
  }else{
    echo "Try again";
  }
}
?>
        </form>
      </div>
      
      
      
      <?php
    }
  }
}
?>
  

