<?php
if(isset($_GET['view_ass'])){
  $id = $_GET['view_ass'];
  $values = ass_detail($id);
  while($row = mysqli_fetch_array($values)){
    $id = $row['0'];
    $title = $row['2'];
    $subject = $row['4'];
    $summary = $row['3'];
    $attachment = $row['8'];
    $will_pay = $row['7'];
    $due_date = $row['6'];
    $post_date = $row['9'];
    $grade = $row['5'];
  }
  ?>
  
  <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Assignment Details</h3>
  </div>
  <div class="panel-body">
     <div>
      <div><b>Assignment ID:</b> <?php echo $id;?></div>
      
      <div><b>Title:</b> <?php echo $title;?></div>
      <div><b>Subject:</b> <?php echo $subject;?></div>
      <div><b>Summary:</b><?php echo $summary;?></div>
      <div><b>User Want:</b> <?php echo $grade;?> <b>(%)</b></div>
      <div><b>Attachments:</b> <a href="index.php?br_as&view_ass=<?php echo $id;?>&attach_file=<?php echo $attachment;?>"><?php echo $attachment;?></a></div>
      <div><b>Will Pay:</b> <b>$</b><?php echo $will_pay;?></div>
      <div><b>Due-Date:</b> <?php echo $due_date;?></div>
      <div><b>Post Date:</b> <?php echo $post_date;?></div>
      <div class="navbar-right" style="margin-right:5px;">
      <span><a href="index.php?br_as&view_ass=<?php echo $id;?>&place_bid=<?php echo $id;?>" class="btn btn-info btn-xs">Place Bid</a></span>
      <span><a href="#" class="btn btn-danger btn-xs">Close</a></span>
      </div>
    </div>
  </div>
</div>
  
  
  <?php
  // download resume file here
if(isset($_GET['attach_file']) && basename($_GET['attach_file'] == $_GET['attach_file'])){
  $filename = $_GET['attach_file'];
  $path = '../files/'.$filename;
  
  if(file_exists($path) && is_readable($path)){
    $size = filesize($path);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename='.$filename);
    header('Content-Transfer-Encoding: binary');
    ob_clean();
    flush();
    $file = @fopen($path,'rb');
    if($file){
      fpassthru($file);
      exit;
    }
  }
}

}
?>
 

