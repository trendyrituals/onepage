<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Withdrawal Balance</h3>
  </div>
  <div class="panel-body table-responsive">
    <form class="form-inline">
  <div class="form-group">
    <label class="sr-only" for="exampleInputEmail3">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Amount eg: 50">
  </div>

  <button type="submit" class="btn btn-default">Withdrawal</button>
</form>
  </div>
</div>