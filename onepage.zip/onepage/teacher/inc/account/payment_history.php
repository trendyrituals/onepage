<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Payment History</h3>
  </div>
  <div class="panel-body table-responsive">
    <table class="table table-bordered">
     <tbody>
      <tr>
        <td><b>#</b>2009</td>
        <td>paypal@ymail.com</td>
        <td><b>$</b>50</td>
        <td>27/10/2017</td>
      </tr>
      <tr>
        <td><b>#</b>2009</td>
        <td>paypal@ymail.com</td>
        <td><b>$</b>50</td>
        <td>27/10/2017</td>
      </tr>
      <tr>
        <td><b>#</b>2009</td>
        <td>paypal@ymail.com</td>
        <td><b>$</b>50</td>
        <td>27/10/2017</td>
      </tr>
      </tbody>
    </table>
  </div>
</div>