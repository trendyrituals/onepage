<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Your Paypal Email</h3>
  </div>
  <div class="panel-body table-responsive">
    <div class="row">
     <?php
        $username = $_SESSION['teach'];
        $list = get_paypal($username);
        while ($row = mysqli_fetch_array($list)){
            $username = $row['1'];
            $email = $row['2'];
            ?>
            <div class="col-md-6"><?php echo $email;?></div>
            <?php
        }
        ?>
      
      <div class="col-md-6"><a href="index.php?ac_bal&edit=<?php echo $_SESSION['teach'];?>" class="btn btn-info btn-sm">Edit Paypal Email</a></div>
    </div>
    
  </div>
</div>