<?php
if(isset($_GET['edit'])){
    ?>
    
    <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Update Paypal Email</h3>
  </div>
  <div class="panel-body">
    
     <form class="navbar-form navbar-left" action="index.php?ac_bal" method="post">
        <div class="form-group">
          <input type="text" name="email" class="form-control" placeholder="eg: alex@gamil.com ">
        </div>
        <button type="submit" name="update_email" class="btn btn-default">Submit</button>
      </form>
    
    
  </div>
</div>
    
    
    <?php
}
?>
<?php
if(isset($_POST['update_email'])){
    $username = $_SESSION['teach'];
    $email = $_POST['email'];
    update_email ($username,$email);
}
?>