<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Amount In Process</h3>
  </div>
  <div class="panel-body table-responsive">
    <table class="table table-bordered">
    <thead>
        <tr>
            <th>BID ID</th>
            <th>ASSIGNMENT ID</th>
            <th>AMOUNT</th>
        </tr>
    </thead>
     <tbody>
     <?php
         $list = complete_bid($_SESSION['teach']);
         while($row = mysqli_fetch_array($list)){
             $id = $row['0'];
             $ass_id = $row['1'];
             $bid_amt = $row['5'];
            ?>
                <tr>
                    <td><?php echo $id;?></td>
                    <td><?php echo $ass_id;?></td>
                    <td><b>$</b><?php echo $bid_amt;?></td>
                </tr>
            
            
            <?php
         }
         ?>
      </tbody>
    </table>
  </div>
</div>