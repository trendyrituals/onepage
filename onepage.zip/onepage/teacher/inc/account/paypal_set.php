<?php
if(isset($_GET['ac_bal'])){
    $username = $_SESSION['teach'];
    $val = set_paypal($username);
    
    if($val == 0){
        ?>
        <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Panel primary</h3>
  </div>
  <div class="panel-body">
    
    <form class="navbar-form navbar-left" action="index.php?ac_bal" method="post">
        <div class="form-group">
          <input type="text" name="email" class="form-control" placeholder="eg: alex@gamil.com ">
        </div>
        <button type="submit" name="set_email" class="btn btn-default">Submit</button>
      </form>
    
    
  </div>
</div>
       
        
        <?php
    }
}
?>
<?php
      if(isset($_POST['set_email'])){
          $username = $_SESSION['teach'];
          $email = $_POST['email'];
          paypal_add($username,$email);
      }
      ?>