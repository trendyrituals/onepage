          <div class="row">
  <div class="col-lg-3">
    <div class="panel panel-primary">
        <a href="#">
           <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3"><i class="fa fa-spinner fa-5x"></i> </div>
            <div class="col-xs-9">
                <div class="text-right huge">11</div>
                <div class="text-right">New Bids</div>
            </div>
            </div>
          </div>
        </a>
        
    </div>
  </div>
  <div class="col-lg-3">
    <div class="panel panel-primary">
        <a href="#">
           <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3"><i class="fa fa-envelope fa-5x"></i> </div>
            <div class="col-xs-9">
                <div class="text-right huge">11</div>
                <div class="text-right">Messages</div>
            </div>
            </div>
          </div>
        </a>
    </div>
  </div>
  <div class="col-lg-3">
    <div class="panel panel-primary">
        <a href="#">
           <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3"><i class="fa fa-money fa-5x"></i> </div>
            <div class="col-xs-9">
                <div class="text-right huge">$ 11</div>
                <div class="text-right">A/c Info</div>
            </div>
            </div>
          </div>
        </a>
    </div>
  </div>
  <div class="col-lg-3">
    <div class="panel panel-primary">
        <a href="#">
           <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3"><i class="fa fa-file fa-5x"></i> </div>
            <div class="col-xs-9">
                <div class="text-right huge">50</div>
                <div class="text-right">Total Posts</div>
            </div>
            </div>
          </div>
        </a>
    </div>
  </div>
</div>