<p><span class="label label-warning">Note</span> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p><br><br>
     
         
          <div class="panel panel-primary">
          <div class="panel-heading">
          <h3 class="panel-title"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Message To Admin</h3>
          </div>
          <div class="panel-body">
          <form class="form-horizontal" action="index.php?ad_msg" method="post">
            <fieldset>
            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textinput">Subject</label>  
              <div class="col-md-4">
              <input id="textinput" name="subject" placeholder="Subject" class="form-control input-md" type="text">

              </div>
            </div>

            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Message</label>
              <div class="col-md-4">                     
                <textarea class="form-control" id="textarea" name="msg"></textarea>
              </div>
            </div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="singlebutton"></label>
              <div class="col-md-4">
                <button type="submit" name="msg_ad" class="btn btn-primary">Send</button>
              </div>
            </div>

            </fieldset>
            </form>
          </div>
          </div>
          
         <?php

if(isset($_POST['msg_ad'])){
    if(!empty($_POST['subject'])&&!empty($_POST['msg'])){
        $subject = $_POST['subject'];
        $msg = $_POST['msg'];
        $username = $_SESSION['teach'];
        echo send_msg_admin($username,$msg,$subject);
    }else{
        echo "Try Again";
    }
}
?>