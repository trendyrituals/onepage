 <div class="container" style="margin-top:70px;">
  <div class="row">
   
    <div class="col-md-3">
     <!--menu here -->
      <?php include ("sidemenu.php");?><!--menu here -->
      
    </div>
    
    
    <div class="col-md-9">
    
    
<?php
        //php blocks start here
if(isset($_GET['br_as'])){
   
    include ("pages/browse_assignment_page.php");
    
    // active task page here
}elseif(isset($_GET['a_task'])){
    
    include ("pages/active_task_page.php");
    
    // profile request page here
}elseif(isset($_GET['pro'])){
    
    include ("pages/profile_page.php");
    
    // bid page here
}elseif(isset($_GET['bid'])){
    
    include ("pages/bids_page.php");
    
    // account balance page here
}elseif(isset($_GET['ac_bal'])){
    
    include("pages/account_page.php");
    
    // admin message page here
}elseif(isset($_GET['ad_msg'])){
   
    include("pages/admin_msg_page.php");
    
    // logout page here
}elseif(isset($_GET['logout'])){
  
    include ("pages/logout.php");
  
  // notification page here
}elseif(isset($_GET['noti'])){
  
    include ("pages/notification_page.php");
  
  // home page here
}else{
    include ("pages/home_page.php");
}
?>
 
     
    </div>
    
    
    </div>
  </div>