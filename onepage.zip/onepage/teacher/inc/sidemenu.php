<div class="panel panel-primary">
        <div class="panel-body">
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php">Dashboard</a></li>
            <li><a href="index.php?br_as">Browse Assignment</a></li>
            <li><a href="index.php?a_task">Active Tasks</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#"> Account Info <span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li><a href="index.php?pro"> Profile</a></li>
                <li><a href="index.php?bid"> Bids</a></li>
                <li><a href="index.php?ac_bal"> Account Balance</a></li>
                <li><a href="index.php?ad_msg"> Message Admin</a></li>
                <li class="divider"></li>
                <li><a href="index.php?logout">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>