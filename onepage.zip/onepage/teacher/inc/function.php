<?php

// show assignments by subject
function subject_assignment($subject){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `subject` = '$subject' ORDER BY id DESC";
  $result = mysqli_query($con,$query);
  return $result;
}


// show all assignments 
function all_subject(){
  global $con;
  $query = "SELECT * FROM `assignment` ORDER BY id DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// this function views the details about assignment
function ass_detail($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

//place bid function
function place_bid($ass_id,$bid_amt,$msg,$grade,$bidder){
  global $con;
  $amt_set = ($bid_amt*10)/100;
  $confirm_bid = $amt_set + $bid_amt;
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  
  $query_bid = "INSERT INTO `bid_table`(`assignment_id`, `bidder_user`, `purposal`, `grade`, `bid_amount`, `date`) VALUES ('$ass_id', '$bidder', '$msg', '$grade', '$bid_amt','$date')";
  $rslt = mysqli_query($con,$query_bid);
  return "Successfully Placed";
  
}

// upload solutions
function upload_solution($bid_id,$post_file){
  global $con;
  $query = "UPDATE `bid_table` SET `solution`='$post_file', `status`='2' WHERE `id` = '$bid_id'";
  $result = mysqli_query($con,$query);
  header("location: index.php?a_task");
}

//this is use for get teacher details for profile
function get_detail($teach){
  global $con;
  $query = "SELECT * FROM teacher WHERE username ='$teach'";
  $result = mysqli_query($con,$query);
  return $result;
  
}

//edit teacher profile
function teach_update_pro($id,$fullname,$dob,$gender,$address,$email,$phone,$about){
  global $con;
  $query = "UPDATE `teacher` SET `fullname`='$fullname',`email`='$email',`phone`='$phone',`gender`='$gender',`dob_date`='$dob',`address`='$address',`about`='$about' WHERE `id`='$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?pro");
}

// user permission finder function 
function find_permission($user){
  global $con;
  $query = "SELECT permission FROM teacher WHERE username = '$user'";
  $result = mysqli_query($con,$query);
  return $result;
}

// user resume details submit
function upload_user_resume($username,$post_resume,$post_degree){
  global $con;
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  $query = "INSERT INTO `resume`(`username`, `resume`, `degree`, `date`) VALUES ('$username','$post_resume','$post_degree','$date')";
  $result = mysqli_query($con,$query);
  return "Successfully Uploaded";
}

// function shows active task
function active_task($username){
  global $con;
  $a = 1;
  $query = "SELECT * FROM `bid_table` WHERE  `bidder_user` = '$username' AND `status` = '$a'";
  $result =mysqli_query($con,$query);
  return $result;
}

// this function view task details 
function view_task($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
  
}

// count bids remains
function count_bid($username){
  global $con;
  $query = "SELECT * FROM `bid_count` WHERE `username` = '$username'";
  $result = mysqli_query($con,$query);
  return $result;
}

// this function shows complete bids which is ready to pay
function complete_bid($username){
    global $con;
    $a = 1;
    $query = "SELECT * FROM `bid_table` WHERE `bidder_user` = '$username' AND `complete` = '$a' AND `receive_pay` = '0' ";
    $result = mysqli_query($con,$query);
    return $result;
} 

// this function get user's paypal address
function get_paypal($username){
    global $con;
    $query = "SELECT * FROM `paypal_email` WHERE `username`='$username'";
    $result = mysqli_query($con,$query);
    return $result;
}

// set paypal email address 
function set_paypal($username){
    global $con;
    $query = "SELECT * FROM `paypal_email` WHERE `username` = '$username'";
    $result = mysqli_query($con,$query);
    $num = mysqli_num_rows($result);
    return $num;
}

// add paypal email 
function paypal_add($username,$email){
    global $con;
    $query = "INSERT INTO `paypal_email`(`username`, `paypal_email`) VALUES ('$username','$email')";
    $result = mysqli_query($con,$query);
    header("location:index.php?ac_bal");
}

// this function updates the paypal email 
function update_email ($username,$email){
    global $con;
    $query = "UPDATE `paypal_email` SET `paypal_email`='$email' WHERE `username` = '$username'";
    $result = mysqli_query($con,$query);
    header("location:index.php?ac_bal");
}

// this is the admin msg function 
function send_msg_admin($username,$msg,$subject){
    global $con;
    date_default_timezone_set('Asia/Kolkata');
    $date = date("Y-m-d");
    $query = "INSERT INTO `message`( `username`, `subject`, `message`, `date`) VALUES ('$username','$subject','$msg','$date')";
    $result = mysqli_query($con,$query);
    return "Message Successfully Send";
}

// check avilable bids
function check_bid($user){
  global $con;
  $query = "SELECT * FROM `bid_count` WHERE `username` = '$user'";
  $result = mysqli_query($con,$query);
  return $result;
}

// cut bid from user bid table 
function cut_bid($user){
  global $con;
  $query = "SELECT * FROM `bid_count` WHERE `username` = '$user'";
  $result = mysqli_query($con,$query);
  return $result;
  }

// update bid
function update_bid($bid_no,$username){
  global $con;
  $a = 1;
  $num = $bid_no - $a;
  $query_up = "UPDATE `bid_count` SET `bid`='$num' WHERE `username` = '$username'";
  $rst = mysqli_query($con,$query_up);
}

// subject list 
function show_subject(){
  global $con;
  $query = "SELECT * FROM subject";
  $result = mysqli_query($con,$query);
  return $result;
}

// count bid on assignmnt 
function count_bid_assignment($id){
  global $con;
  $query = "SELECT * FROM `bid_table` WHERE `assignment_id` = '$id'";
  $result = mysqli_query($con,$query);
  $num = mysqli_num_rows($result);
  return $num;
}

// assignment title 
function ass_name($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  while ($row = mysqli_fetch_array($result)){
    $title = ucfirst($row['2']);
    return $title;
  }
}

// assignment due date show in active task 
function ass_due_date($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  while ($row = mysqli_fetch_array($result)){
    $date = $row['6'];
    return $date;
  }
}

// function for show open notification
function show_open_noti($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '0' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// function for show close notification
function show_close_noti($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// read noti update
function read_noti($user){
  global $con;
  $query = "UPDATE `notification` SET `read`='1' WHERE `username` = '$user' AND `read` = '0'";
  $result  = mysqli_query($con,$query);
}

// fuction for notification span
function noti_row($user){
  global $con;
  $query = "SELECT * FROM `notification` WHERE `username` = '$user' AND `read` = '0'";
  $result = mysqli_query($con,$query);
  $num = mysqli_num_rows($result);
  return $num;
}

// post comment
function comment_post($id,$msg,$post_attachment){
  global $con;
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  $query = "INSERT INTO `comment`(`ass_id`, `msg`, `file`, `date`) VALUES ('$id','$msg','$post_attachment','$date')";
  $result = mysqli_query($con,$query);  
}

// show comment
function show_comment($id){
  global $con;
  $query = "SELECT * FROM `comment` WHERE `status` = '1' AND `ass_id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// solution notification for student 
function inform_student($bid_id){
  global $con;
  $query = "SELECT * FROM `bid_table` WHERE `id` = '$bid_id'";
  $result = mysqli_query($con,$query);
  while ($row = mysqli_fetch_array($result)){
    $ass_id = $row['1'];
    $query_sec = "SELECT * FROM `assignment` WHERE `id` = '$ass_id'";
    $rslt = mysqli_query($con,$query_sec);
    while($rows = mysqli_fetch_array($rslt)){
      $username = $rows['1'];
      $noti = "New Solution Uploaded take a look ";
      date_default_timezone_set('Asia/Kolkata');
      $date = date("Y-m-d");
      $qu = "INSERT INTO `notification`(`username`, `noti`, `date`) VALUES ('$username','$noti','$date')";
      $rlt = mysqli_query($con,$qu);
      
    }
  }
}














?>