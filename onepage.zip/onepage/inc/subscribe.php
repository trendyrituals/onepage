    
  <!-- subscribe btn and follow socila media -->  
  <div class="container animated bounceInUp">
    <div class="panel panel-default" style="margin-top:50px;">
      <div class="panel-body">
        <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
        <input type="text" class="form-control" placeholder="example@zmail.com">
        </div>
        <button type="submit" class="btn btn-success">Subscribe</button>
        </form>
        
      
        
        <div class="navbar-right" style="margin-right:5px;">
         <lebal>Follow Us:</lebal>
          <button type="button" style="background:#3B5998;color:white;" class="btn btn-default  navbar-btn">Facebook</button>
        <button type="button" style="background:#1DA1F2;color:white;" class="btn btn-default navbar-btn">Twitter</button>
        <button type="button" style="background:#E62117;color:white;" class="btn btn-default navbar-btn">Youtube</button>
        </div>
        
      </div>
    </div>
  </div><!-- subscribe btn and follow socila media --> 