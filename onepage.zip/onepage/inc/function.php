<?php
function registration_std($username,$fullname,$email,$mobile,$password,$re_password){
  global $con;
  $query = "SELECT * FROM student Where username='$username'";
  $result = mysqli_query($con,$query);
  $num_row = mysqli_num_rows($result);
  if($num_row>0){
    echo "<h5><p class=\"text-warning\">Username Already Exist</p></h5>";
  }else{
    if($password == $re_password){
      date_default_timezone_set('Asia/Kolkata'); 
      $date= date("Y-m-d");
      $query = "INSERT INTO `student`(`username`, `fullname`, `email`, `phone`, `password`, `date`) VALUES ('$username','$fullname','$email','$mobile','$password','$date')";
      $result = mysqli_query($con,$query);
      return "<h5><p class=\"text-success\">Successfully Registered</p></h5>";
    }else{
      
      echo "<h5><p class=\"text-danger\">Password Dont Match With Repeat Password</p></h5>";
    }
    
  }
}



function registration_teacher($username,$fullname,$email,$mobile,$password,$re_password){
  global $con;
  $query = "SELECT * FROM teacher Where username='$username'";
  $result = mysqli_query($con,$query);
  $num_row = mysqli_num_rows($result);
  if($num_row>0){
    echo "<h5><p class=\"text-warning\">Username Already Exist</p></h5>";
  }else{
    if($password == $re_password){
      date_default_timezone_set('Asia/Kolkata'); 
      $date= date("Y-m-d");
      $query = "INSERT INTO `teacher`(`username`, `fullname`, `email`, `phone`, `password`, `date`) VALUES ('$username','$fullname','$email','$mobile','$password','$date')";
      $result = mysqli_query($con,$query);
      return "<h5><p class=\"text-success\">Successfully Registered</p></h5>";
    }else{
      
      echo "<h5><p class=\"text-danger\">Password Dont Match With Repeat Password</p></h5>";
    }
    
  }
}



function login($username,$password){
  global $con;
  
  $query = "select * from student where password='$password' AND username='$username'";
  $result = mysqli_query($con,$query);
  $rows = mysqli_num_rows($result);
  if ($rows == 1) {
    session_start();
    $_SESSION['std']=$username; // Initializing Session
    header("location: student/index.php"); // Redirecting To dashborad Page
    
    }elseif($rows!= 1){
    $query = "select * from teacher where password='$password' AND username='$username'";
  $result = mysqli_query($con,$query);
  $rowss = mysqli_num_rows($result);
  if ($rowss == 1) {
    session_start();
    $_SESSION['teach']=$username; // Initializing Session
    header("location: teacher/index.php"); // Redirecting to the teacher dashboard
    echo "teacher";
    }elseif($rowss != 1){
    $query = "select * from admin where password='$password' AND username='$username'";
  $result = mysqli_query($con,$query);
  $rows = mysqli_num_rows($result);
  if ($rows == 1) {
    session_start();
    $_SESSION['admin']=$username; // Initializing Session
    header("location: admin/index.php"); // Redirecting To dashborad Page
    
    }else{
    echo "not found";
  }
  }
  }
}
?>