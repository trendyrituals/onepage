  <div class="contact-screen animated bounceInRight">
    <img src="img/page-image-seasons.jpg" alt="">
</div>

<div class="contact-heading col-md-2 animated bounceInDown">
    <h3>Contact Us</h3>
</div>