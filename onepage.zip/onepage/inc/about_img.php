<!--about image  -->
<div class="about-screen animated bounceInRight">
<img src="img/blue_flower.jpg" alt="">
</div><!--abouut image  -->
 <div class="about-heading col-md-2 animated bounceInLeft">
<h3>About Us</h3>
</div>