<!-- Full Width Image Header -->
    <header class="header-image">
        <div class="headline">
            <div class="container animated bounceInDown ">
                <h1>One Page Wonder</h1>
                <h2>Will Knock Your Socks Off</h2>
            </div>
        </div>
    </header>