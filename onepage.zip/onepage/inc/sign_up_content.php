<div class="container">
<!--signuo form and details s  -->
<div class="row signup-txt">


<div class="col-md-6 sign-txt ">
<?php include ("inc/sign_condition.php");?>
</div>


<div class="col-md-6 sign-form">
<?php include ("inc/sign.php");?>
</div><!-- -->


</div>
</div>