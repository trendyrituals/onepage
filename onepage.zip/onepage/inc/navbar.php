    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Agent Orange</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php?about">About</a>
                    </li>
                    <li>
                        <a href="index.php?services">Services</a>
                    </li>
                    <li>
                        <a href="index.php?contactus">Contact</a>
                    </li>
                    <li>
                        <a href="index.php?signup">Sign Up</a>
                    </li>
                </ul>
                
                
                <form class="navbar-form navbar-right" action="index.php" method="post" role="search">
                        <div class="form-group">
                          <input type="text" class="form-control" name="username" placeholder="Username">
                        </div>
                         <div class="form-group">
                          <input type="password" class="form-control" name="password" placeholder="password">
                        </div>
                        <button type="submit" class="btn btn-primary" name="login">Login</button>
                         <?php

if(isset($_POST['login'])){
  $username = mysqli_real_escape_string($con,$_POST['username']);
  $password = mysqli_real_escape_string($con,$_POST['password']);
  
  login($username,$password);
}
?>
                      </form>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    
   
  
