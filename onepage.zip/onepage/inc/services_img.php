  <div class="contact-screen animated bounceInRight">
    <img src="img/red_leaf.jpg" alt="">
</div>

<div class="services-heading col-md-2 animated bounceInDown">
    <h3>Services</h3>
</div>