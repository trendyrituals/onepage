   <form action="index.php?signup" method="post" style="margin-top:30px;">
        	
        	
        	    <div class="form-group col-lg-6">
					<label>User Name</label>
					<input type="" name="username" class="form-control" id="" value="">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Full Name</label>
					<input type="" name="fullname" class="form-control" id="" value="">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Email</label>
					<input type="text" name="email" class="form-control" id="" value="">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Mobile</label>
					<input type="text" name="mobile" class="form-control" id="" value="">
				</div>
								
				<div class="form-group col-lg-6">
					<label>Password</label>
					<input type="password" name="password" class="form-control" id="" value="">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Repeat Password</label>
					<input type="password" name="re_password" class="form-control" id="" value="">
				</div>			
				
				<div class="form-group col-lg-6">
				    	<button type="submit" name="std" class="btn btn-primary">Register</button>
				</div>
				
    </form>
    
    <?php

if(isset($_POST['std'])){
  if(!empty($_POST['username']) && !empty($_POST['fullname']) && !empty($_POST['email']) && !empty($_POST['mobile']) && !empty($_POST['password']) && !empty($_POST['re_password'])){
    $username = mysqli_real_escape_string($con,$_POST['username']);
    $fullname = mysqli_real_escape_string($con,$_POST['fullname']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $mobile = mysqli_real_escape_string($con,$_POST['mobile']);
    $password = mysqli_real_escape_string($con,$_POST['password']);
    $re_password = mysqli_real_escape_string($con,$_POST['re_password']);
    
    
    echo $confirm = registration_std($username,$fullname,$email,$mobile,$password,$re_password);
  }else{
    echo "<h4><p class=\"text-danger\">Fields Missing</p></h4>";
  }
}






?>