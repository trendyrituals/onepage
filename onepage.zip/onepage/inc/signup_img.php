<div class="signup-screen animated bounceInDown">
<img src="img/Most-Beautiful-Purple-Flower-Wallpaper.jpg" alt="">
</div>


<div class="signup-heading col-md-2 animated bounceInLeft">
<h3>Ragistration</h3>
</div>