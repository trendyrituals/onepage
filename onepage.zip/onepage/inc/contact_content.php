<!--form -->
    <div class="col-md-8 navbar-right">
       <?php include ("inc/contact_form.php");?>
    </div><!--form  -->