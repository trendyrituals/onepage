<ul class="nav nav-tabs">
  <li class="active"><a href="#student" data-toggle="tab">Student</a></li>
  <li><a href="#teacher" data-toggle="tab">Teacher</a></li>
  <li class="disabled"><a>Freelancer</a></li>
  <li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
      Help <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
      <li><a href="#dropdown1" data-toggle="tab">Info</a></li>
      <li class="divider"></li>
      <li><a href="#dropdown2" data-toggle="tab">Blogs</a></li>
    </ul>
  </li>
</ul>
<div id="myTabContent" class="tab-content">
 
  <div class="tab-pane fade active in" id="student">
    <?php include ("inc/student_registration.php");?>    
  </div>
  
  <div class="tab-pane fade" id="teacher">
    <?php include ("inc/teacher_registration.php");?>
  </div>
  
  <div class="tab-pane fade" id="dropdown1">
    <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny pack lo-fi farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone skateboard locavore carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings gentrify squid 8-bit cred pitchfork.</p>
  </div>
</div>
        