<html>
	<head>
		<title>BBC News</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
	</head>

<body>

  <!-- header here -->
  <div><?php include ("includes/header.php");?></div>

  <!-- navbar here -->
  <div><?php include ("includes/navbar.php");?></div>
  
  
  <div class="container">
    <!-- side bar here-->
  <div><?php include ("includes/sidebarpage.php");?></div>
  
  <!-- contant area here -->
  <div><?php include ("includes/pagecontent.php");?></div>

  </div>
  

  
  


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>