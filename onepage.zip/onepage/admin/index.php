

<?php
session_start();
if($_SESSION['admin']){
  require_once ("inc/db.php");
  require_once ("inc/function.php");
  include ("inc/header.php");
  include ("inc/navbar.php");
  include ("inc/content.php");
  include ("inc/footer.php");
}

?>
 
  
  
  
  
  
