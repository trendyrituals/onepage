     <div>
        <h4>Solution List</h4>
        <hr>
              
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>ASSINGMENT ID</th>
              <th>BID ID</th>
              <th>FILE</th>
              <th>DATE</th>
            </tr>
          </thead>
          <tbody>
           
          
            <tr>
              <td>1</td>
              <td>2</td>
              <td>3</td>
              <td><a href="">text.txt</a></td>
              <td>2016-9-27</td>
            </tr>
         
           
                    
          </tbody>
         </table>
        </div>
         
       </div>