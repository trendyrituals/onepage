<div>
  <ul class="nav nav-pills nav-stacked">
    <li class="active"><a href="index.php?sol">New Solution</a></li>
    
  </ul>
</div>

       