     <div>
        <h4>Teachers List</h4>
        <hr>
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>Username</th>
              <th>Full Name</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Registration Date</th>
            
            </tr>
          </thead>
          <tbody>
           
           <?php
            $list = all_teachers();
            while($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $username = $row['1'];
              $fullname = $row['2'];
              $st = $row['13'];
              if($st == '1'){
                $status = "Active";
              }else{
                $status = "No Active";
              }
             
              $date = $row['12'];
              $phone = $row['4'];
              ?>
              
              <tr>
              <td><?php echo $id;?></td>
              <td><?php echo $username;?></td>
              <td><?php echo $fullname;?></td>
              <td><?php echo $phone;?></td>
              <td><?php echo $status;?></td>
              <td><?php echo $date;?></td>
              
            </tr>
              
              
              <?php
            }
            ?>
            
           
            
          </tbody>
         </table>
        </div>
         
       </div>