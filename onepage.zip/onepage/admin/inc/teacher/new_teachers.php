     <div>
        <h4>New Teachers List</h4>
        <hr>        
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>USERNAME</th>
              <th>EMAIL</th>
              <th>PHONE</th>
              <th>RESUME</th>
              <th>DEGREE</th>
              <th>DATE</th>
              <th>OPTION</th>
            </tr>
          </thead>
          <tbody>
           <?php
            $list = new_teacher();
            while($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $username = $row['1'];
              $email = $row['4'];
              $phone = $row['3'];
              $date = $row['2'];
              $resume = $row['5'];
              $degree = $row['6'];
              ?>
              
              <tr>
              <td><?php echo $id;?></td>
              <td><?php echo $username;?></td>
              <td><?php echo $email;?></td>
              <td><?php echo $phone;?></td>
              <td><a href="index.php?teachers&new_teach&resume=<?php echo $resume;?>"><?php echo $resume;?></a></td>
              <td><a href="index.php?teachers&new_teach&degree=<?php echo $degree;?>"><?php echo $degree;?></a></td>
              <td><?php echo $date;?></td>
              <td>
              <a href="index.php?teachers&new_teach&yes=<?php echo $id;?>&read=<?php echo $username;?>" class="btn btn-success btn-xs">Approve</a>
              <a href="index.php?teachers&new_teach&read=<?php echo $username;?>" class="btn btn-danger btn-xs">Reject</a>
              </td>
            </tr>
              
              <?php
            }
            
            ?>
            
            
           
          </tbody>
         </table>
        </div>
         
       </div>
       <?php

// download resume file here
if(isset($_GET['resume']) && basename($_GET['resume'] == $_GET['resume'])){
  $filename = $_GET['resume'];
  $path = 'user_data/resume/'.$filename;
  
  if(file_exists($path) && is_readable($path)){
    $size = filesize($path);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename='.$filename);
    header('Content-Transfer-Encoding: binary');
    ob_clean();
    flush();
    $file = @fopen($path,'rb');
    if($file){
      fpassthru($file);
      exit;
    }
  }
}

// download degree file here
if(isset($_GET['degree']) && basename($_GET['degree'] == $_GET['degree'])){
  $filename = $_GET['degree'];
  $path = 'user_data/degree/'.$filename;
  
  if(file_exists($path) && is_readable($path)){
    $size = filesize($path);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename='.$filename);
    header('Content-Transfer-Encoding: binary');
    ob_clean();
    flush();
    $file = @fopen($path,'rb');
    if($file){
      fpassthru($file);
      exit;
    }
  }
}


if(isset($_GET['yes'])){
  $user_id = $_GET['yes'];
  
  permission($user_id);
  
}

if(isset($_GET['read'])){
  $username = $_GET['read'];
  read_resume($username);
}
?>