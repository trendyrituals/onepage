<div>
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php?teachers">Teachers</a></li>
            <li><a href="index.php?teachers&teach_id">Teachers By ID</a></li>
            <li><a href="index.php?teachers&new_teach">New Registered Teachers</a></li>
          </ul>
        </div>