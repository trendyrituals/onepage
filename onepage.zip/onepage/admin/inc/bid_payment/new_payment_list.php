     <div>
        <h4>New Bids Payment</h4>
        <hr>
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>ASSIGNMENT</th>
              <th>BIDDER</th>
              <th>BID AMT</th>
              <th>RECEVIE AMT</th>
              <th>DATE</th>
              <th>VIEW</th>
            </tr>
          </thead>
          <tbody>
           <?php
            $list = new_assign_bids();
            while($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $ass_id = $row['1'];
              $bidder = $row['2'];
              $bid_amt = $row['5'];
              $con_amt = $row['6'];
              $date = $row['7'];
              ?>
              
              <tr>
              <td><?php echo $id;?></td>
              <td><?php echo $ass_id;?></td>
              <td><?php echo $bidder;?></td>
              <td><?php echo $bid_amt;?></td>
              <td><?php echo $con_amt;?></td>
              <td><?php echo $date;?></td>
              <td><a href="index.php?pay_receive&bid=<?php echo $id;?>&bidder=<?php echo $bidder;?>" class="btn btn-success btn-xs">Assign</a></td>
            </tr>
            
              
              <?php
            }
            ?>
            
            
            
          </tbody>
         </table>
        </div>
         
       </div>
       
<?php
if(isset($_GET['bid']) && isset($_GET['bidder'])){
  $id = $_GET['bid'];
  assign_bid($id);
  $username = $_GET['bidder'];
  noti_bidder($username,$id);
}

?>