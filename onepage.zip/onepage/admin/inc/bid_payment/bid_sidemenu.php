<div>
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php?pay_receive">New Bids Payment</a></li>
            <li><a href="index.php?pay_receive&hist">Bid Payment History</a></li>
          </ul>
        </div>