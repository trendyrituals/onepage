     <div>
        <h4>Bid Payment History</h4>
        <hr>
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>ASSIGNMENT</th>
              <th>BIDDER</th>
              <th>BID AMT</th>
              <th>RECEVIE AMT</th>
              <th>DATE</th>
              <th>OPTION</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $list = old_bid();
             while($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $ass_id = $row['1'];
              $bidder = $row['2'];
              $bid_amt = $row['5'];
              $con_amt = $row['6'];
              $date = $row['7'];
               ?>
               
             <tr>
              <td><?php echo $id;?></td>
              <td><?php echo $ass_id;?></td>
              <td><?php echo $bidder;?></td>
              <td><?php echo $bid_amt;?></td>
              <td><?php echo $con_amt;?></td>
              <td><?php echo $date;?></td>
              <td><a href="#" class="btn btn-primary btn-xs">View</a></td>
            </tr>
               
               
               <?php
             }
            ?>
           
          </tbody>
         </table>
        </div>
         
       </div>