<!--content here -->
  <div class="container-fluid">
    <div class="row">
     <!--side menu -->
      <div class="col-md-2">
          <?php
        if(isset($_GET['teachers'])){
          include("inc/teacher/teachers_menu.php");
        }elseif(isset($_GET['students'])){
          include("inc/student/student_menu.php");
        }elseif(isset($_GET['pay_receive'])){
          include("inc/bid_payment/bid_sidemenu.php");
        }elseif(isset($_GET['ad_sub'])){
          include("inc/subject/subject_menu.php");
        }elseif(isset($_GET['all_ass'])){
          include("inc/assignment/assignment_menu.php");
        }elseif(isset($_GET['msg'])){
          include("inc/msg/msg_menu.php");
        }elseif(isset($_GET['comment'])){
          include("inc/comment/side_comment.php");
        }elseif(isset($_GET['sol'])){
          include("inc/solution/side_sol.php");
        }elseif(isset($_GET['issue_pay'])){
          include("inc/pay_teacher/pay_side.php");
        }
        ?>
      </div>
      <!-- content area -->
      <div class="col-md-10">
  <?php
        if(isset($_GET['teachers'])){
          include("page/teacher_page.php");
        }elseif(isset($_GET['students'])){
          include("page/all_student_page.php");
        }elseif(isset($_GET['pay_receive'])){
          include("page/bid_payment_page.php");
        }elseif(isset($_GET['ad_sub'])){
          include("page/subject_page.php");
        }elseif(isset($_GET['all_ass'])){
          include("page/assignment_page.php");
        }elseif(isset($_GET['msg'])){
          include("page/msg_page.php");
        }elseif(isset($_GET['comment'])){
          include("page/comment_page.php");
        }elseif(isset($_GET['sol'])){
          include("page/solution_page.php");
        }elseif(isset($_GET['issue_pay'])){
          include("page/pay_teacher_page.php");
        }elseif(isset($_GET['logout'])){
          include("page/logout.php");
        }else{
          include("page/home_page.php");
        }
        ?>
        
        
      </div>
    </div>
  </div>
  
  <!--content here -->