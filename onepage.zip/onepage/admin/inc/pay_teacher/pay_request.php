<h4>Payment Request</h4>
<hr>


<div class="table-responsive">
  

<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>ASSIGNMENT ID</th>
      <th>BID ID</th>
      <th>BID AMOUNT</th>
      <th>PAYPAL EMAIL</th>
      <th>OPTION</th>
    </tr>
  </thead>
  <tbody>
   
      <tr>
        <td>1</td>
        <td>2</td>
        <td>20</td>
        <td>bhawani.singh8@gmail.com</td>
        <td><a href="" class="btn btn-info btn-xs">pay</a></td>
      </tr>

    
  </tbody>
  </table>
</div>