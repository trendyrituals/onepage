<?php
// all acive assingmnets 
function active_ass(){
  global $con;
  $query  = "SELECT * FROM `assignment` WHERE `status` ='0' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}


// all close assingmnets 
function close_ass(){
  global $con;
  $query  = "SELECT * FROM `assignment` WHERE `status` ='2' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}


// this function gets details for the assignment
function get_ass($id){
  global $con;
  $query = "SELECT * FROM `assignment` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// all student 
function all_student(){
  global $con;
  $query = "SELECT * FROM `student` ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// student details by id
function std_details($id){
  global $con;
  $query = "SELECT * FROM `student` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// all teachers list 
function all_teachers(){
  global $con;
  $query = "SELECT * FROM `teacher` WHERE `permission` ='1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// get teacher deatils by id
function get_teacher($id){
  global $con;
  $query = "SELECT * FROM `teacher` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// new teacher resume functions
function new_teacher(){
  global $con;
  $query = "SELECT teacher.id,teacher.username,teacher.date,teacher.phone,teacher.email,resume.resume,resume.degree
FROM teacher
INNER JOIN resume
ON teacher.username=resume.username WHERE resume.read='0'";
  $result = mysqli_query($con,$query);
  return $result;
}

// permission function for teacher
function permission($user_id){
  global $con;
  $query = "UPDATE `teacher` SET `permission`='1' WHERE `id`='$user_id'";
  $result = mysqli_query($con,$query);
  
}

// resume read confirm step
function read_resume($username){
  global $con;
  $query = "UPDATE `resume` SET `read`='1' WHERE `username` = '$username'";
  $result = mysqli_query($con,$query);
  header("location:index.php?teachers&new_teach");
}

// add subject to the subject table
function add_subject($subject){
  global $con;
  $query = "INSERT INTO `subject`(`subject`) VALUES ('$subject')";
  $result = mysqli_query($con,$query);
  return "Subject Added To The Subject Table";
}

// show subject list to the admin
function show_subject(){
  global $con;
  $query = "SELECT * FROM `subject`";
  $result = mysqli_query($con,$query);
  return $result;
}

// delete subject fro the subject table
function delete_subject($id){
  global $con;
  $query = "DELETE FROM `subject` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?ad_sub");
}

// show all new assign bids to the admin
function new_assign_bids(){
  global $con;
  $query = "SELECT * FROM `bid_table` WHERE `clear_pay` = '1' AND `assign` != '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// show old bid which is paid
function old_bid(){
  global $con;
  $query = "SELECT * FROM `bid_table` WHERE `clear_pay` = '1' AND `assign` = '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// assign bid to the tutor
function assign_bid($id){
  global $con;
  $query = "UPDATE `bid_table` SET `assign`='1' WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?pay_receive");
}

// notification for the teacher
function noti_bidder($username,$id){
  global $con;
  $noti = "Bid ID ".$id." Assign To You";
  date_default_timezone_set('Asia/Kolkata');
  $date = date("Y-m-d");
  $query = "INSERT INTO `notification`(`username`, `noti`, `date`) VALUES ('$username','$noti','$date')";
  $result = mysqli_query($con,$query);
}

// admin msg list new msgs
function admin_msg(){
  global $con;
  $query = "SELECT * FROM `message` WHERE `read` = '0' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// admin old msg list new msgs
function admin_old_msg(){
  global $con;
  $query = "SELECT * FROM `message` WHERE `read` = '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// view msg to admin
function get_msg($id){
  global $con;
  $query = "SELECT * FROM `message` WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  return $result;
}

// make read count to for the msg
function make_read($id){
  global $con;
  $query = "UPDATE `message` SET `read`='1' WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
}

// shoe new comments 
function new_comments(){
  global $con;
  $query = "SELECT * FROM `comment` WHERE `read` = '0'";
  $result = mysqli_query($con,$query);
  return $result;
}

// permission for the comment
function active_the_comment($id){
  global $con;
  $query = "UPDATE `comment` SET `status`='1',`read`='1' WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?comment");
}

// permission for the comment
function close_the_comment($id){
  global $con;
  $query = "UPDATE `comment` SET `status`='0',`read`='1' WHERE `id` = '$id'";
  $result = mysqli_query($con,$query);
  header("location:index.php?comment");
}

// show active comments
function show_active_comment(){
  global $con;
  $query = "SELECT * FROM `comment` WHERE `status` = '1' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}

// show close comments
function show_close_comment(){
  global $con;
  $query = "SELECT * FROM `comment` WHERE `status` = '0' ORDER BY `id` DESC";
  $result = mysqli_query($con,$query);
  return $result;
}









?>