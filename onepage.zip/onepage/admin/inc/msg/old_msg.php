<h4>Old Messages</h4>
<hr>

<div>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>#</th>
      <th>FROM</th>
      <th>SUBJECT</th>
      <th>MESSAGE</th>
      <th>DATE</th>
      <th>OPTION</th>
    </tr>
  </thead>
  <tbody>
   <?php
    $list = admin_old_msg();
    while ($row = mysqli_fetch_array($list)){
      $id = $row['0'];
      $username = $row['1'];
      $subject = $row['2'];
      $msg = substr($row['3'],0,15);
      $date = $row['4'];
      ?>
      
      <tr>
        <td><?php echo $id;?></td>
        <td><?php echo $username;?></td>
        <td><?php echo $subject;?></td>
        <td><?php echo $msg;?></td>
        <td><?php echo $date;?></td>
        <td><a href="index.php?msg&oldread=<?php echo $id;?>" class="btn btn-primary btn-xs">Read</a></td>
      </tr>
      
      <?php
    }
    ?>
    
  </tbody>
  </table>
</div>