<?php
if(isset($_GET['read'])){
  $id = $_GET['read'];
  $list = get_msg($id);
  while ($row=mysqli_fetch_array($list)){
    $id = $row['0'];
    $username = $row['1'];
    $subject = $row['2'];
    $msg = $row['3'];
    $date = $row['4'];
    
    make_read($id);
    
    ?>
    
    <div class="well">
      <div><b>Username:</b> <?php echo $username;?></div>
      <div><b>Subject:</b> <?php echo $subject;?></div>
      <div><b>Message:</b> <?php echo $msg;?></div>
      <div><b>Date:</b> <?php echo $date;?></div>
      <div>
      <a href="index.php?msg" class="btn btn-info btn-sm">Reply By Mail</a>
      <a href="index.php?msg" class="btn btn-danger btn-sm">Close</a>
      </div>
    </div>
    
    <?php
  }
}
?>





<?php

if(isset ($_GET['oldread'])){
  $id = $_GET['oldread'];
  $list = get_msg($id);
  while ($row=mysqli_fetch_array($list)){
    $id = $row['0'];
    $username = $row['1'];
    $subject = $row['2'];
    $msg = $row['3'];
    $date = $row['4'];

    
    ?>
    
    <div class="well">
      <div><b>Username:</b> <?php echo $username;?></div>
      <div><b>Subject:</b> <?php echo $subject;?></div>
      <div><b>Message:</b> <?php echo $msg;?></div>
      <div><b>Date:</b> <?php echo $date;?></div>
      <div>
      <a href="index.php?msg&old_msg" class="btn btn-info btn-sm">Reply By Mail</a>
      <a href="index.php?msg&old_msg" class="btn btn-danger btn-sm">Close</a>
      </div>
    </div>
    
    <?php
  }
}

?>