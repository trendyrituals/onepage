<div>
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php?msg">New Messages</a></li>
            <li><a href="index.php?msg&old_msg">Old_messages</a></li>
          </ul>
        </div>