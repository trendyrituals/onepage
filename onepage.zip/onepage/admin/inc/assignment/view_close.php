<?php
if(isset($_GET['view_ass'])){
  $id = $_GET['view_ass'];
  $details = get_ass($id);
  while($row = mysqli_fetch_array($details)){
    $id = $row['0'];
    $username = $row['1'];
    $title = $row['2'];
    $subject = $row['4'];
    $summary = $row['3'];
    $due = $row['6'];
    $post = $row['10'];
    $bid = $row['13'];
    $attachment = $row['8'];
    $grade = $row['5'];
    ?>
    
    <div>
      <div><b>Assignment ID:</b> <?php echo $id;?></div>
      <div><b>Username:</b> <?php echo $username;?></div>
      
      <div><b>Title:</b> <?php echo $title;?></div>
      <div><b>Subject:</b> <?php echo $subject;?></div>
      <div><b>Summary:</b><?php echo $summary;?></div>
      <div><b>User Want:</b> <?php echo $grade;?> <b>(%)</b></div>
      <div><b>Attachments:</b> <?php echo $attachment;?></div>
      <div><b>Bid Assign:</b> <?php echo $bid;?></div>
      <div><b>Due-Date:</b> <?php echo $due;?></div>
      <div><b>Post Date:</b> <?php echo $post;?></div>
      <div class="navbar-right" style="margin-right:5px;">
      <span><a href="index.php?all_ass&close&view_ass" class="btn btn-danger btn-xs">Close</a></span>
      </div>
    </div>
    
    
    
    <?php
  }
}
?>