<h4>Active Assignments</h4>
<hr>


<div class="table-responsive">
  

<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>#</th>
      <th>TITLE</th>
      <th>SUBJECT</th>
      <th>SUMMARY</th>
      <th>DUE DATE</th>
      <th>POST DATE</th>
      <th>OPTION</th>
    </tr>
  </thead>
  <tbody>
   <?php
    $list = active_ass();
    while ($row = mysqli_fetch_array($list)){
      $id = $row['0'];
      $title = $row['2'];
      $subject = $row['4'];
      $summary = substr($row['3'],0,40);;
      $due = $row['6'];
      $post = $row['10'];
      ?>
      
      <tr>
      <td><?php echo $id;?></td>
      <td><?php echo $title;?></td>
      <td><?php echo $subject;?></td>
      <td><?php echo $summary;?></td>
      <td><?php echo $due;?></td>
      <td><?php echo $post;?></td>
      <td><a href="index.php?all_ass&view_ass=<?php echo $id;?>" class="btn btn-primary btn-xs">View</a></td>
    </tr>
      
      <?php
    }
    ?>
    
  </tbody>
  </table>
</div>