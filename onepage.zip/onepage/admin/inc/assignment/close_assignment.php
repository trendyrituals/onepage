<h4>Close Assignments</h4>
<hr>


<div>
  

<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>#</th>
      <th>TITLE</th>
      <th>SUBJECT</th>
      <th>SUMMARY</th>
      <th>ASSIGN BID</th>
      <th>POST DATE</th>
      <th>OPTION</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $list = close_ass();
    while ($row = mysqli_fetch_array($list)){
      $id = $row['0'];
      $title = $row['2'];
      $subject = $row['4'];
      $summary = substr($row['3'],0,40);;
      $bid = $row['13'];
      $post = $row['10'];
      ?>
      
      <tr>
      <td><?php echo $id;?></td>
      <td><?php echo $title;?></td>
      <td><?php echo $subject;?></td>
      <td><?php echo $summary;?></td>
      <td><?php echo $bid;?></td>
      <td><?php echo $post;?></td>
      <td><a href="index.php?all_ass&close&view_ass=<?php echo $id;?>" class="btn btn-primary btn-xs">View</a></td>
    </tr>
      
      <?php
    }
    ?>
    
  </table>
</div>