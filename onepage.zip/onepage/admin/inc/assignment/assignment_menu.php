<div>
  <ul class="nav nav-pills nav-stacked">
    <li class="active"><a href="index.php?all_ass">All Active Assignments</a></li>
    <li><a href="index.php?all_ass&close">Close Assignments</a></li>
  </ul>
</div>