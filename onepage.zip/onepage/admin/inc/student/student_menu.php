<div>
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php?students">Students</a></li>
            <li><a href="index.php?students&std_id">Students By ID</a></li>
          </ul>
        </div>