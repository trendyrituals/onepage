     <div>
        <h4>All Students List</h4>
        <hr>
              
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>Username</th>
              <th>Full Name</th>
              <th>Phone</th>
              <th>Registration Date</th>
            </tr>
          </thead>
          <tbody>
           
           <?php
            $list = all_student();
            while ($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $username = $row['1'];
              $fullname = $row['2'];
              $phone = $row['4'];
              $date = $row['11'];
              ?>
              
            <tr>
              <td><?php echo $id;?></td>
              <td><?php echo $username;?></td>
              <td><?php echo $fullname;?></td>
              <td><?php echo $phone;?></td>
              <td><?php echo $date;?></td>
            </tr>
            
              
              <?php
            }
            ?>
           
            
                        
          </tbody>
         </table>
        </div>
         
       </div>