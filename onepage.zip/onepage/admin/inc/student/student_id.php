<div>
  <h4>Student Details</h4>
  <hr>
  <div class="col-md-4">
    <form class="navbar-form navbar-left" action="index.php?students&std_id" method="post" role="search">
        <div class="form-group">
          <input class="form-control" placeholder="User ID" name="id" type="text">
        </div>
        <button type="submit" name="st_id" class="btn btn-default">Search</button>
      </form>
  </div>
  
  <?php
  if(isset($_POST['st_id'])){
    $id = $_POST['id'];
    $list = std_details($id);
    while($row = mysqli_fetch_array($list)){
      $id = $row['0'];
      $username = $row['1'];
      $fullname = $row['2'];
      $email = $row['3'];
      $phone = $row['4'];
      $add = $row['8'];
      $date = $row['11'];
      $about = $row['9'];
      ?>
      
       <div class="col-md-9">
    <div class="panel panel-default">
      <div class="panel-body">
        <h4>Student Details</h4>
        <hr>
        <div style="margin-bottom:5px;"><b>ID:</b> <?php echo $id;?></div>
        <div style="margin-bottom:5px;"><b>Username:</b> <?php echo $username;?></div>
        <div style="margin-bottom:5px;"><b>Fullname:</b> <?php echo $fullname;?></div>
        <div style="margin-bottom:5px;"><b>Email:</b> <?php echo $email;?></div>
        <div style="margin-bottom:5px;"><b>Phone:</b> <?php echo $phone;?></div>
        <div style="margin-bottom:5px;"><b>Address:</b> <?php echo $add;?></div>
        <div style="margin-bottom:5px;"><b>Registration Date:</b> <?php echo $date;?></div>
        <div style="margin-bottom:5px;"><b>About:</b> <?php echo $about;?></div>
        
      </div>
    </div>
  </div>
      
      <?php
    }
  }
  ?>
  
  
  
 
  
</div>