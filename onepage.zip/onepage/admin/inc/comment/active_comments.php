     <div>
        <h4>Active Comments</h4>
        <hr>
        <div class="table-responsive">
          <table class="table table-striped table-hover ">
          <thead>
            <tr>
              <th>#</th>
              <th>ASSIGNMENT</th>
              <th>COMMENT</th>
              <th>FILE</th>
              <th>STATUS</th>
              <th>DATE</th>
            </tr>
          </thead>
          <tbody>
           <?php
            $list = show_active_comment();
            while ($row = mysqli_fetch_array($list)){
              $id = $row['0'];
              $ass_id = $row['1'];
              $com = $row['2'];
              $file = $row['3'];
              $date = $row['4'];
              $state = $row['5'];
              if($state == '1'){
                $status = "active";
              }else{
                $status = "close";
              }
              ?>
              
              <tr>
               <td><?php echo $id;?></td>
               <td><?php echo $ass_id;?></td>
               <td><?php echo $com;?></td>
               <td><a href="index.php?comment&ac_com&attach=<?php echo $file;?>"><?php echo $file;?></a></td>
               <td><?php echo $status;?></td>
               <td><?php echo $date;?></td>
             </tr>

              <?php
            }
            ?>
           
           
           
           
           
           
          </tbody>
          </table>
       </div>
</div>

<?php
            // download file here
if(isset($_GET['attach']) && basename($_GET['attach'] == $_GET['attach'])){
  $filename = $_GET['attach'];
  $path = '../files/'.$filename;
  
  if(file_exists($path) && is_readable($path)){
    $size = filesize($path);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename='.$filename);
    header('Content-Transfer-Encoding: binary');
    ob_clean();
    flush();
    $file = @fopen($path,'rb');
    if($file){
      fpassthru($file);
      exit;
    }
  }
}
            
            ?>
