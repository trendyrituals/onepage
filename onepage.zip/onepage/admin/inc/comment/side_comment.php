<div>
  <ul class="nav nav-pills nav-stacked">
    <li class="active"><a href="index.php?comment">New Comments</a></li>
    <li><a href="index.php?comment&ac_com">Active Comments</a></li>
    <li><a href="index.php?comment&close_com">Close Comments</a></li>
  </ul>
</div>