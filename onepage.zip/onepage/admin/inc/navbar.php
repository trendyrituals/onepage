
 <!--navbar here -->
 <nav class="navbar navbar-inverse navbar-static-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">Admin Panel</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      <ul class="nav navbar-nav">
        <li><a href="index.php?msg">Messages</a></li>
        <li><a href="index.php?teachers">All Teachers</a></li>
        <li><a href="index.php?students">All Students</a></li>
        <li><a href="index.php?all_ass">All Assignments</a></li>
        <li><a href="index.php?pay_receive">New Bids Assign</a></li>
        <li><a href="index.php?comment">Comments</a></li>
        <li><a href="index.php?sol">Solutions</a></li>
        <li><a href="index.php?issue_pay">Issue Payment</a></li>
        
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Settings <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?ad_sub">Add Subjects</a></li>
            <li class="divider"></li>
            <li><a href="index.php?logout">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
 <!--navbar here -->