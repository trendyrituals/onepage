<div>


<div class="col-md-3" style="margin-right:10px;margin-top:10px;text-align:center;border:5px solid #18BC9C;">
 <a href="index.php?students" style="color:#222222;">
  <h1><i class="fa fa-graduation-cap fa-4x"></i></h1>
  <h3>Students</h3>
  <h5>103</h5>
 </a>
  
</div>


<div class="col-md-3" style="margin-right:10px;margin-top:10px;text-align:center;border:5px solid #18BC9C;">
  <a href="index.php?teachers&new_teach" style="color:#222222;">
    <h1><i class="fa fa-user fa-4x"></i></h1>
  <h3>New Teachers</h3>
  <h5>2</h5>
  </a>
</div>


<div class="col-md-3" style="margin-right:10px;margin-top:10px;text-align:center;border:5px solid #18BC9C;">
  <a href="index.php?msg" style="color:#222222;">
    <h1><i class="fa fa-envelope fa-4x"></i></h1>
  <h3>New Messages</h3>
  <h5>2</h5>
  </a>
</div>


<div class="col-md-3" style="margin-right:10px;margin-top:10px;text-align:center;border:5px solid #18BC9C;">
  <a href="index.php?pay_receive" style="color:#222222;">
    <h1><i class="fa fa-black-tie fa-4x"></i></h1>
  <h3>New Bids Assign</h3>
  <h5>2</h5>
  </a>
</div>


<div class="col-md-3" style="margin-right:10px;margin-top:10px;text-align:center;border:5px solid #18BC9C;">
  <a href="" style="color:#222222;">
    <h1><i class="fa fa-file-archive-o fa-4x"></i></h1>
  <h3>New Solution</h3>
  <h5>2</h5>
  </a>
</div>
 
  
</div>