<form class="navbar-form navbar-left" action="index.php?ad_sub" method="post" role="search">
  <div class="form-group">
    <input class="form-control" name="sub" placeholder="Subject Name" type="text">
  </div>
  <button type="submit" name="ad_sub" class="btn btn-default">Add Subject</button>
</form>


<?php
if(isset ($_POST['ad_sub'])){
  $subject = ucfirst($_POST['sub']);
  echo add_subject($subject);
}
?>