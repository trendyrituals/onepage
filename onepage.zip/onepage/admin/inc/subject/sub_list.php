<div style="margin-top:100px;">
  <h4>Subject List</h4>
<hr>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>#</th>
      <th>SUBJECT</th>
      <th>OPTION</th>
    </tr>
  </thead>
  <tbody>
   <?php
    $list = show_subject();
    while ($row=mysqli_fetch_array($list)){
      $id = $row['0'];
      $sub = $row['1'];
      ?>
      <tr>
        <td><?php echo $id;?></td>
        <td><?php echo $sub;?></td>
        <td><a href="index.php?ad_sub&del=<?php echo $id;?>" class="btn btn-danger btn-xs">Delete</a></td>
      </tr>
      
      <?php
    }
    ?>
    
  </tbody>
</table>
</div>


<?php
if(isset($_GET['del'])){
  $id = $_GET['del'];
  delete_subject($id);
}
?>