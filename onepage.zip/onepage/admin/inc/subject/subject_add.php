<h4>Add Subject</h4>
<hr>

<?php include ("inc/subject/sub_form.php");?>
<?php include ("inc/subject/sub_list.php");?>


