<div>
          <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php?ad_sub">Add Subjects</a></li>
            
          </ul>
        </div>
        
       