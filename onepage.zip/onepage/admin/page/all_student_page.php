<?php
if(isset($_GET['std_id'])){
  include("inc/student/student_id.php");
}elseif(isset($_GET['students'])){
  include("inc/student/all_student.php");
}

  


?>