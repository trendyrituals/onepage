<?php
if(isset($_GET['ac_com'])){
  include ("inc/comment/active_comments.php");
}elseif(isset($_GET['close_com'])){
  include ("inc/comment/close_comment.php");
}else{
  include ("inc/comment/comment_list.php");
}


?>