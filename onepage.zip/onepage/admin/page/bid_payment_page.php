<?php
if(isset($_GET['hist'])){
  include("inc/bid_payment/payment_history.php");
}else{
  include("inc/bid_payment/new_payment_list.php");
}

?>