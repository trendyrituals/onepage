<?php

if(isset($_GET['close'])){
  include("inc/assignment/view_close.php");
  include("inc/assignment/close_assignment.php");
}else{
  include("inc/assignment/view_ass.php");
  include("inc/assignment/all_assignment.php");
}
?>