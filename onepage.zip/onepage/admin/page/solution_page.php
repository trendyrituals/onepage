<?php

  include ("inc/solution/new_solution.php");

?>