<?php
if(isset($_GET['ad_sub'])){
  include("inc/subject/subject_add.php");
}
?>