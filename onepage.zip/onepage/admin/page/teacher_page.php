<?php
if(isset($_GET['new_teach'])){
  include("inc/teacher/new_teachers.php");
}elseif(isset($_GET['teach_id'])){
  include("inc/teacher/teacher_id.php");
}else{
  include("inc/teacher/all_teachers.php");
}

?>