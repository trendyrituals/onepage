<?php
include ("inc/home/main.php");
?>